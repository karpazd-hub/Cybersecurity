#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
LAB_DIR="$(cd -- "${SCRIPT_DIR}/.." >/dev/null 2>&1 && pwd)"
CERT_DIR="${LAB_DIR}/nginx/certs"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Missing required command: $1" >&2
    exit 1
  fi
}

require_cmd openssl

mkdir -p "$CERT_DIR"
umask 077

cat >&2 <<'TODO'
TODO: zaimplementuj generowanie certyfikatow.

Wymagane pliki wynikowe:
  nginx/certs/student-ca.key
  nginx/certs/student-ca.crt
  nginx/certs/student-server.key
  nginx/certs/student-server.csr
  nginx/certs/student-server.crt

Wskazowki:
  - Wygeneruj klucz prywatny dla lokalnego CA.
  - Stworz self-signed certyfikat CA z nginx/certs/ca.cnf.
  - Wygeneruj klucz prywatny i CSR dla serwera.
  - Podpisz CSR serwera lokalnym CA.
  - Przy podpisywaniu uzyj nginx/certs/server.cnf oraz rozszerzen v3_req.
  - Zweryfikuj wynik poleceniem openssl verify.

Checker oczekuje dokladnie takich nazw plikow jak powyzej.
TODO

echo "[1/5] Generowanie klucza prywatnego CA (4096-bit RSA)..."
openssl genrsa -out "${CERT_DIR}/student-ca.key" 4096

echo "[2/5] Tworzenie self-signed certyfikatu CA (365 dni)..."
openssl req -new -x509 \
  -key "${CERT_DIR}/student-ca.key" \
  -out "${CERT_DIR}/student-ca.crt" \
  -days 365 \
  -config "${CERT_DIR}/ca.cnf"

echo "[3/5] Generowanie klucza prywatnego serwera (2048-bit RSA)..."
openssl genrsa -out "${CERT_DIR}/student-server.key" 2048

echo "[4/5] Tworzenie CSR dla serwera..."
openssl req -new \
  -key "${CERT_DIR}/student-server.key" \
  -out "${CERT_DIR}/student-server.csr" \
  -config "${CERT_DIR}/server.cnf"

echo "[5/5] Podpisywanie certyfikatu serwera przez lokalne CA..."
openssl x509 -req \
  -in "${CERT_DIR}/student-server.csr" \
  -CA "${CERT_DIR}/student-ca.crt" \
  -CAkey "${CERT_DIR}/student-ca.key" \
  -CAcreateserial \
  -out "${CERT_DIR}/student-server.crt" \
  -days 365 \
  -extensions v3_req \
  -extfile "${CERT_DIR}/server.cnf"

echo
echo "Weryfikacja certyfikatu serwera..."
openssl verify -CAfile "${CERT_DIR}/student-ca.crt" "${CERT_DIR}/student-server.crt"

echo
echo "SAN w certyfikacie serwera:"
openssl x509 -in "${CERT_DIR}/student-server.crt" -noout -text \
  | grep -A1 "Subject Alternative Name"

echo
echo "Certyfikaty wygenerowane w: ${CERT_DIR}"
ls -la "${CERT_DIR}"/*.key "${CERT_DIR}"/*.crt "${CERT_DIR}"/*.csr 2>/dev/null || true
