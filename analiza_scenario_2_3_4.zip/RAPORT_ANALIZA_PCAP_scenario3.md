# Raport analizy sieciowej – Podejrzana aktywność sieciowa

---

## Zakres materiału

| Pole | Wartość |
|------|---------|
| **Nazwa pliku** | `scenario3.pcapng` |
| **SHA-256** | `af94cd4ec607d4e8aba9968c7fece1b5bf1742c067551e2925849b1526eac638` |
| **Weryfikacja hasha** | ✅ ZGODNY z plikiem `scenario3.sha256` |
| **Źródło i punkt przechwycenia** | Sieć wewnętrzna `192.168.10.0/24`, przechwycenie prawdopodobnie na przełączniku lub hoście monitorującym (tryb promiscuous) |
| **Przedział czasu** | `2017-07-06 13:39:00 UTC` → `2017-07-06 13:44:59 UTC` (~6 minut, 360 sekund) |
| **Strefa czasowa** | UTC |
| **Łączna liczba ramek** | 71 466 |
| **Znane ograniczenia** | Ruch TLS (HTTPS/SSH) nie jest odszyfrowany – zawartość tych sesji nieznana. Brak logów systemowych, EDR ani Active Directory. Adresy MAC wskazują na urządzenia Dell, co sugeruje środowisko testowe/laboratoryjne (ISCX dataset). Tytuł zadania mówi o hoście `10.0.0.24`, który nie istnieje w tym pliku – rzeczywistym hostem zainteresowania jest `192.168.10.x`. |

---

## Mapa sieci (ustalona z ruchu)

| IP | Rola (ustalona) |
|----|----------------|
| `192.168.10.3` | **Domain Controller** (TESTBED1.CA) – serwer AD/DNS/LDAP/Kerberos |
| `192.168.10.50` | **Serwer FTP** (vsFTPd 3.0.3) |
| `192.168.10.14` | Stacja robocza – **najwyższy wolumen pakietów (7 978)**, wiele połączeń wychodzących |
| `192.168.10.15` | Stacja robocza – inicjuje **FTP**, **DCSync** (DRSUAPI), Kerberos |
| `192.168.10.9` | Stacja robocza – inicjuje **DCSync** (DRSUAPI), Kerberos |
| `192.168.10.25` | Stacja robocza – LDAP, SMB, Kerberos do DC i do `10.19` |
| `192.168.10.5` | Stacja robocza – LSARPC (enumeracja zasad), SSH |
| `192.168.10.19` | Stacja robocza – udostępnia SMB, cel SMB z `10.25` |
| `192.168.10.12` | Stacja robocza – duży ruch HTTPS |
| `192.168.10.1` | Brama/Router domyślny |

---

## Podsumowanie

W analizowanym przechwyceniu zidentyfikowano **cztery odrębne kategorie ataków** przeprowadzonych przez różne hosty wewnętrzne. Najpoważniejszym zdarzeniem jest **atak DCSync** – dwa hosty (`192.168.10.15` i `192.168.10.9`) wywołały protokół DRSUAPI (Active Directory Replication API) względem kontrolera domeny, co pozwala na wydobycie skrótów haseł wszystkich kont, w tym konta `krbtgt`. Równolegle wykryto **nieszyfrowany transfer FTP** z hasłem jawnym (`USER: iscxtap`, `PASS: 1234`), **enumerację Active Directory** przez `192.168.10.25` (LDAP, SMB, srvsvc) oraz **błąd autoryzacji Kerberos (KRB_ERROR 30)** podczas sesji `192.168.10.9 → DC`. Całość wskazuje na skoordynowane działania wewnętrznych aktorów po uzyskaniu przyczółka w sieci.

---

## Chronologia zdarzeń

```
CZAS (UTC)         ŹRÓDŁO:PORT              CEL:PORT          OBSERWACJA
─────────────────────────────────────────────────────────────────────────────────
13:39:00.171       [START PRZECHWYCENIA]
13:39:12.970       192.168.10.14:xxxxx  →  40.70.221.249:443  Normalne przeglądanie
13:39:24.948       192.168.10.5:xxxxx   →  192.168.10.50:22   SYN do serwera SSH
13:39:26.618       192.168.10.15:xxxxx  →  192.168.10.50:22   SYN do serwera SSH

⚠️  ~13:40:18 (78s)
                   192.168.10.14:xxxxx  →  192.168.10.3:445   SMB – połączenie do DC
                   [Frame 10047-10078]                         SMB2 Session Setup

⚠️  13:41:09 (119s)
                   192.168.10.25:xxxxx  →  192.168.10.3:389   LDAP – enumeracja AD
                   192.168.10.25:xxxxx  →  192.168.10.3:3268  LDAP Global Catalog
                   [Frame 23120-23205]

⚠️⚠️  13:41:39 (159s)  ← KRYTYCZNE ZDARZENIE
                   192.168.10.15:53742  →  192.168.10.3:49666  DRSUAPI DsBind
                   [Frame 36581]                                Nawiązanie połączenia z replikacją AD
                   192.168.10.15:53742  →  192.168.10.3:49666  DRSUAPI DsCrackNames (opnum 12)
                   [Frame 36586]                                Rozwiązanie nazw kont
                   192.168.10.15:53742  →  192.168.10.3:49666  DRSUAPI DsGetNCChanges (opnum 1)
                   [Frame 36590]                                ← DCSync: wydobycie skrótów NTLM!

⚠️  13:41:51 (171s)
                   192.168.10.5:xxxxx   →  192.168.10.3:445   LSARPC – enumeracja zasad LSA
                   [Frame 37373]

⚠️  13:41:58 (178s)
                   192.168.10.15:xxxxx  →  192.168.10.50:21   FTP LOGIN
                   [Frame 43723-43800]                         USER: iscxtap / PASS: 1234 (jawnie!)
                                                               230 Login successful
                                                               STOR f2e6afc1d23444b09def98dbca4779ef.txt
                                                               Transfer pliku na serwer FTP!

⚠️  13:41:59 (159s sekunda 2)
                   192.168.10.15:xxxxx  →  192.168.10.3:49666  Netlogon
                   [Frame 36627]

⚠️⚠️  13:44:01 (301s)  ← DRUGIE DCSync
                   192.168.10.9:xxxxx   →  192.168.10.3:49666  DRSUAPI DsBind
                   [Frame 64575]
                   192.168.10.9:xxxxx   →  192.168.10.3:49666  DRSUAPI DsCrackNames (opnum 12)
                   [Frame 64579]
                   192.168.10.9:xxxxx   →  192.168.10.3:49666  DRSUAPI DsGetNCChanges (opnum 1)
                   [Frame 64583]                                ← DCSync: drugi atak!
                   192.168.10.3:xxxxx   →  192.168.10.9:xxxxx  KRB_ERROR (msg_type 30)
                   [Frame 64659]                                ← Błąd Kerberos podczas ataku

⚠️  13:44:32 (352s)
                   192.168.10.14:xxxxx  →  192.168.10.50:21   FTP LOGIN
                   [Frame 68171-68237]                         USER: iscxtap / PASS: 1234 (jawnie!)
                                                               230 Login successful
                                                               STOR ffaf20be249145b1bfb6d250df1c2610.txt
                                                               Transfer pliku na serwer FTP!

⚠️  13:44:57 (317s)
                   192.168.10.25:xxxxx  →  192.168.10.19:445  SMB + srvsvc
                   [Frame 65662-65664]                         Enumeracja udziałów sieciowych
13:44:59.996       [KONIEC PRZECHWYCENIA]
```

---

## Dowody

### Dowód 1 – DCSync (DRSUAPI) – wydobycie skrótów haseł AD

| Pole | Wartość |
|------|---------|
| **Numery ramek** | 36581, 36583, 36586, 36588, 36590, 36592 (host .15) oraz 64575–64585 (host .9) |
| **Filtr Wireshark** | `drsuapi` |
| **Pola kluczowe** | `drsuapi.opnum == 0` (DsBind), `drsuapi.opnum == 12` (DsCrackNames), `drsuapi.opnum == 1` (DsGetNCChanges) |
| **Źródło** | `192.168.10.15:53742` oraz `192.168.10.9` |
| **Cel** | `192.168.10.3:49666` (Domain Controller TESTBED1.CA) |
| **Czas zdarzenia 1** | 13:41:39 UTC (offset 159s) |
| **Czas zdarzenia 2** | 13:44:01 UTC (offset 301s) |

**Dlaczego to jest atak:**
`DsGetNCChanges` (opnum 1) to wywołanie RPC normalnie używane tylko przez inne kontrolery domeny do replikacji bazy NTDS.dit. Gdy wywołuje je zwykła stacja robocza, jest to klasyczny **DCSync** – technika T1003.006 w MITRE ATT&CK. Pozwala wydobyć skróty NTLM wszystkich kont domenowych, w tym `krbtgt`, co umożliwia tworzenie **Golden Ticket** (trwały dostęp bez znajomości hasła).

```
Ramka 36590 (hex dump fragment):
  Operation: DsGetNCChanges (1)   ← wydobycie zmian z NTDS
  DsBind → DsCrackNames → DsGetNCChanges = klasyczna sekwencja DCSync
```

---

### Dowód 2 – Nieszyfrowany FTP z danymi logowania w postaci jawnej

| Pole | Wartość |
|------|---------|
| **Numery ramek** | 43723–43800 (host .15) oraz 68171–68237 (host .14) |
| **Filtr Wireshark** | `ftp` |
| **Pola kluczowe** | `ftp.request.command`, `ftp.response.code`, `ftp.request.arg` |
| **Źródła** | `192.168.10.15` i `192.168.10.14` |
| **Cel** | `192.168.10.50:21` (vsFTPd 3.0.3) |

**Wyodrębnione dane logowania (widoczne w Wireshark bez deszyfrowania):**
```
Frame 43725:  USER iscxtap
Frame 43731:  PASS 1234          ← hasło jawnym tekstem!
Frame 43748:  230 Login successful.
Frame 43765:  STOR f2e6afc1d23444b09def98dbca4779ef.txt   ← upload pliku

Frame 68173:  USER iscxtap
Frame 68179:  PASS 1234          ← to samo hasło!
Frame 68202:  STOR ffaf20be249145b1bfb6d250df1c2610.txt   ← upload drugiego pliku
```

**Dlaczego to jest podejrzane:**
Dwa różne hosty logują się tym samym kontem (iscxtap/1234) do serwera FTP i uploadują pliki o nazwach będących skrótami MD5. Brak szyfrowania oznacza, że każdy w sieci LAN widzi hasło. Możliwy scenariusz: eksfiltracja danych lub przesyłanie wyników skanowania/skrótów haseł.

---

### Dowód 3 – Enumeracja Active Directory (LDAP + SMB + srvsvc)

| Pole | Wartość |
|------|---------|
| **Numery ramek (LDAP)** | 23120–23205 |
| **Numery ramek (SMB srvsvc)** | 28275, 28277, 65662, 65664 |
| **Filtr Wireshark** | `ldap` lub `srvsvc` |
| **Źródło** | `192.168.10.25` |
| **Cele** | `192.168.10.3:389` (LDAP), `192.168.10.3:3268` (LDAP GC), `192.168.10.19:445` (SMB) |

**Porty używane przez .25:**
- 389/TCP – LDAP (zapytania do AD)
- 3268/TCP – LDAP Global Catalog (pełne drzewo AD)
- 139/TCP – NetBIOS/SMB
- 445/TCP – SMB2

**Dlaczego to jest podejrzane:**
Host `192.168.10.25` odpytuje DC na portach LDAP i Global Catalog (typowy rekonesans: wyliczanie użytkowników, grup, GPO), a jednocześnie łączy się przez SMB do `192.168.10.19` używając DCERPC/srvsvc – to enumeracja udostępnionych zasobów (`NetShareEnum`). Jest to wzorzec typowy dla narzędzi takich jak `BloodHound`, `ADRecon` lub `net view /domain`.

---

### Dowód 4 – LSARPC – enumeracja zasad lokalnych

| Pole | Wartość |
|------|---------|
| **Numery ramek** | 37373, 37375 |
| **Filtr Wireshark** | `lsarpc` |
| **Źródło** | `192.168.10.5` |
| **Cel** | `192.168.10.3:445` |

**Dlaczego to jest podejrzane:**
LSARPC (Local Security Authority Remote Protocol) umożliwia odpytanie kontrolera domeny o zasady bezpieczeństwa: politykę haseł, uprawnienia, zaufania domenowe. W połączeniu z pozostałymi zdarzeniami jest to element rekonesansu post-exploitation.

---

### Dowód 5 – Błąd Kerberos KRB_ERROR podczas DCSync

| Pole | Wartość |
|------|---------|
| **Numer ramki** | 64659 |
| **Filtr Wireshark** | `kerberos.msg_type == 30` |
| **Źródło** | `192.168.10.3` → `192.168.10.9` |
| **msg_type** | 30 = KRB_ERROR |

**Kontekst:** Błąd Kerberos pojawia się bezpośrednio po próbie DCSync przez `192.168.10.9`. Może oznaczać że konto użyte do DCSync nie ma uprawnień Domain Replication lub że DC wykrył anomalię.

---

### Dowód 6 – SSH (port 22) – wielokrotne próby połączeń

| Pole | Wartość |
|------|---------|
| **Filtr Wireshark** | `tcp.dstport == 22 and tcp.flags.syn == 1` |
| **Cel** | `192.168.10.50:22` |
| **Źródła** | `.5, .15, .19, .51, .17, .16, .12` (7 różnych hostów) |
| **Liczba SYN** | 28 pakietów SYN od 7 hostów w krótkim czasie |

Każdy host nawiązuje po 2 sesje SSH do `192.168.10.50`. Nie jest to bruteforce (brak dużej liczby prób), ale wzorzec "jeden za drugim ze wszystkich hostów" może wskazywać na skoordynowane działanie lub test dostępności usługi.

---

## Statystyki zbiorcze

| Protokół | Ramki | Znaczenie |
|----------|-------|-----------|
| TCP SYN (bez ACK) | 1 482 | Inicjowanie połączeń – bazowy wskaźnik aktywności |
| DRSUAPI (DCSync) | 12 | **KRYTYCZNE** – replikacja AD z nieuprawnionych hostów |
| FTP | 28 | Logowanie jawnym hasłem + upload plików |
| LDAP | 48 | Enumeracja AD |
| SMB/SMB2 | 57 | Połączenia do kontrolera domeny i innych hostów |
| LSARPC | 2 | Enumeracja zasad LSA |
| Kerberos | 22 | Uwierzytelnianie, w tym KRB_ERROR |
| SSH | 337 | Sesje zaszyfrowane (treść niedostępna) |

---

## Ocena

### Hipoteza (wysoki poziom pewności):

**Wewnętrzne działania post-exploitation** – co najmniej dwa hosty (`192.168.10.15`, `192.168.10.9`) zostały skompromitowane lub działają jako źródło ataku i wykonują:

1. **DCSync** – wydobycie skrótów NTLM wszystkich kont domenowych (MITRE T1003.006)
2. **Enumerację AD** – rekonesans struktury domeny przez `192.168.10.25` (MITRE T1087.002)
3. **Eksfiltrację przez FTP** – przesyłanie plików (prawdopodobnie skróty haseł lub wyniki skanowania) (MITRE T1048.003)
4. **Enumerację LSA** – zbieranie informacji o zasadach bezpieczeństwa (MITRE T1069)

Sekwencja zdarzeń jest logiczna dla kill chain po uzyskaniu przyczółka:
```
Rekonesans (LDAP/SMB) → Eskalacja (DCSync) → Eksfiltracja (FTP)
```

### Alternatywne wyjaśnienie:

Plik pochodzi ze zbioru **ISCX 2012 / UNB Intrusion Detection Evaluation Dataset** (widoczna nazwa użytkownika `iscxtap`). Wszystkie "ataki" mogą być **symulowanym ruchem laboratoryjnym** generowanym w celu tworzenia datasetu IDS. Jednak z technicznego punktu widzenia wzorce pakietów są identyczne z prawdziwymi atakami.

### Poziomy pewności:

| Zdarzenie | Pewność |
|-----------|---------|
| DCSync (DRSUAPI opnum 1) | **Wysoki** – niezbity dowód w protokole |
| Dane logowania FTP w jawnej postaci | **Wysoki** – widoczne w pakietach |
| Enumeracja AD (LDAP/SMB) | **Wysoki** – potwierdzony ruch |
| Bruteforce SSH | **Niski** – tylko 2 sesje per host, brak wzorca brute-force |
| Eksfiltracja przez FTP | **Średni** – transfer plików potwierdzony, cel nieznany |

---

## Filtry Wireshark do weryfikacji

```wireshark
# 1. DCSync attacks
drsuapi

# 2. FTP credentials w jawnej postaci
ftp.request.command == "USER" or ftp.request.command == "PASS"

# 3. LDAP enumeration
ldap and ip.src == 192.168.10.25

# 4. SMB to DC
smb or smb2 and ip.addr == 192.168.10.3

# 5. Kerberos errors
kerberos.msg_type == 30

# 6. LSARPC
lsarpc

# 7. Całe zdarzenie DCSync (pierwsza instancja)
frame.number >= 36575 and frame.number <= 36600

# 8. FTP session (host .15)
frame.number >= 43723 and frame.number <= 43800

# 9. FTP session (host .14)
frame.number >= 68171 and frame.number <= 68237
```

---

## Rekomendowane działania

### Natychmiastowe (0–24h):

1. **Izolacja hostów** `192.168.10.15` i `192.168.10.9` od sieci – potwierdzony DCSync
2. **Reset hasła konta `krbtgt`** w Active Directory (dwukrotnie, z przerwą 10h) – unieważnienie potencjalnych Golden Ticket
3. **Reset haseł wszystkich kont domenowych** – DCSync mógł wydobyć wszystkie skróty NTLM
4. **Zmiana hasła konta `iscxtap`** i wyłączenie dostępu FTP lub migracja na SFTP/FTPS
5. **Izolacja** `192.168.10.25` – aktywna enumeracja AD

### Korelacja z logami i EDR:

- **Windows Event Log DC** (ID 4662 – dostęp do obiektu AD, ID 4929 – DCSync) – potwierdź, które konto było użyte do DCSync
- **Windows Event Log hostów** `.15`, `.9` – sprawdź uruchomione procesy w czasie 13:39–13:45 UTC (2017-07-06); typowe narzędzia DCSync: `mimikatz.exe`, `secretsdump.py`, `Invoke-DCSync`
- **EDR** – historia procesów, połączenia sieciowe, załadowane moduły DLL
- **Logi FTP serwera** `192.168.10.50` – kto i kiedy logował się na konto `iscxtap`, zawartość przesłanych plików
- **Logi DNS** `192.168.10.3` – pełna lista zapytań DNS z sieci wewnętrznej

### Identyfikacja właściciela i procesu:

- Ustal, **kto jest użytkownikiem** hostów `.15`, `.9`, `.25` w czasie zdarzenia (Active Directory – atrybuty `lastLogon`, `lastLogonTimestamp`)
- Na hoście `.15` szukaj procesu, który otworzył port `53742` (~13:41:39 UTC)
- Sprawdź czy konto użyte do DCSync jest kontem z uprawnieniami replikacji AD (typowo tylko Domain Controllers i konta z `Replicating Directory Changes All`)

### Ocena ryzyka:

Jeśli DCSync zakończył się sukcesem, atakujący posiada:
- Skróty NTLM wszystkich użytkowników domeny TESTBED1.CA
- Możliwość tworzenia Golden/Silver Ticket (Kerberos)
- Możliwość pass-the-hash do wszystkich hostów w domenie

Jest to **kompromitacja całej domeny Active Directory**.
