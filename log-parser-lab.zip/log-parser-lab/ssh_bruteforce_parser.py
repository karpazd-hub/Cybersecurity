#!/usr/bin/env python3
"""
ssh_bruteforce_parser.py — Lab 20: parser logów SSH i IOC.

Narzędzie:
  * czyta plik auth.log linia po linii (bez wczytywania całości do pamięci),
  * wybiera linie z nieudanym logowaniem hasłem ("Failed password"),
  * wyciąga źródłowy adres IP (oraz użytkownika i timestamp),
  * zlicza nieudane logowania per IP i oznacza IP przekraczające próg,
  * porównuje zaobserwowane IP z listą IOC,
  * zapisuje raport JSON (i opcjonalnie CSV) do katalogu output/.

Plik źródłowy jest otwierany wyłącznie w trybie odczytu i nie jest modyfikowany.

Przykłady uruchomienia:
    python ssh_bruteforce_parser.py
    python ssh_bruteforce_parser.py --input data/auth-sample.log --threshold 3
    python ssh_bruteforce_parser.py --filter-only
    python ssh_bruteforce_parser.py --no-csv --no-ioc
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import ipaddress
import json
import re
import sys
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Konfiguracja
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_INPUT = BASE_DIR / "data" / "auth-sample.log"
DEFAULT_IOC = BASE_DIR / "data" / "ioc-ips.txt"
DEFAULT_OUTPUT_DIR = BASE_DIR / "output"
JSON_NAME = "ssh-bruteforce-summary.json"
CSV_NAME = "ssh-bruteforce-summary.csv"
DEFAULT_THRESHOLD = 3
DEFAULT_TOP = 10
ENCODING = "utf-8"

# Część 3 — tekst charakterystyczny dla nieudanego logowania hasłem.
FAILED_MARKER = "Failed password"

# Część 4 — wzorzec ekstrakcji (raw string + grupy przechwytujące).
# Grupa "ip" to KANDYDAT na IPv4 — pełna walidacja odbywa się osobno (ipaddress).
FAILED_LOGIN_RE = re.compile(
    r"Failed password for (?P<invalid>invalid user )?(?P<user>\S*) "
    r"from (?P<ip>\d{1,3}(?:\.\d{1,3}){3}) port (?P<port>\d+)"
)

# Nagłówek linii syslog — tylko do (opcjonalnego) wyciągnięcia timestampu.
# Obsługuje klasyczny format "Jul 24 10:00:01" oraz ISO 8601 (rsyslog / journald).
HEADER_RE = re.compile(
    r"^(?P<timestamp>[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}"
    r"|\d{4}-\d{2}-\d{2}T\S+)\s+(?P<host>\S+)\s+"
)

# Dodatkowy kontekst: udane logowania z tego samego IP (hasło lub klucz).
ACCEPTED_RE = re.compile(
    r"Accepted (?P<method>\S+) for (?P<user>\S+) "
    r"from (?P<ip>\d{1,3}(?:\.\d{1,3}){3}) port \d+"
)

DISCLAIMER = (
    "Wynik jest sygnałem analitycznym, a nie automatycznym potwierdzeniem incydentu. "
    "Przekroczenie progu oznacza jedynie, że liczba nieudanych logowań z danego IP "
    "była większa niż przyjęta wartość graniczna. Dopasowanie do listy IOC oznacza "
    "zgodność z listą referencyjną, a nie dowód ataku. Wynik wymaga weryfikacji "
    "przez analityka (kontekst, okno czasowe, udane logowania, inne źródła logów)."
)

MAX_ERROR_SAMPLES = 10
MAX_EXCERPT_LEN = 160


class InputFileError(Exception):
    """Czytelny błąd dotyczący pliku wejściowego (brak, katalog, brak uprawnień)."""


# ---------------------------------------------------------------------------
# Struktury danych
# ---------------------------------------------------------------------------

@dataclass
class IpStats:
    failed_logins: int = 0
    invalid_user_attempts: int = 0
    users: Counter = field(default_factory=Counter)
    first_seen: str | None = None
    last_seen: str | None = None


@dataclass
class AnalysisResult:
    source_file: str
    lines_analyzed: int = 0
    lines_matched_filter: int = 0
    lines_parsed_ok: int = 0
    lines_parse_errors: int = 0
    lines_skipped: int = 0
    parse_error_reasons: Counter = field(default_factory=Counter)
    parse_error_samples: list = field(default_factory=list)
    per_ip: dict = field(default_factory=dict)              # ip -> IpStats
    successful_logins: Counter = field(default_factory=Counter)  # ip -> liczba


# ---------------------------------------------------------------------------
# Część 2 — odczyt pliku
# ---------------------------------------------------------------------------

def validate_input_file(path: Path) -> Path:
    """Sprawdza, czy ścieżka istnieje i jest zwykłym plikiem."""
    if not path.exists():
        raise InputFileError(f"Plik wejściowy nie istnieje: {path}")
    if not path.is_file():
        raise InputFileError(
            f"Ścieżka wejściowa nie jest plikiem (np. jest katalogiem): {path}"
        )
    return path


def iter_lines(path: Path):
    """Generator: zwraca kolejne linie pliku bez wczytywania całości do pamięci."""
    try:
        # Tryb "r" = tylko odczyt; plik źródłowy nie może zostać zmieniony.
        with path.open("r", encoding=ENCODING, errors="replace") as handle:
            for line_number, line in enumerate(handle, start=1):
                yield line_number, line.rstrip("\r\n")
    except PermissionError as exc:
        raise InputFileError(f"Brak uprawnień do odczytu pliku: {path}") from exc


def display_path(path: Path) -> str:
    """Ścieżka do raportu: względna wobec katalogu projektu, jeśli to możliwe."""
    resolved = path.resolve()
    for base in (BASE_DIR, Path.cwd()):
        try:
            return resolved.relative_to(base).as_posix()
        except ValueError:
            continue
    return str(resolved)


def sha256_of_file(path: Path, chunk_size: int = 65536) -> str:
    """Skrót pliku liczony porcjami — pozwala potwierdzić, że źródło się nie zmieniło."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


# ---------------------------------------------------------------------------
# Część 3 i 4 — filtr i ekstrakcja pól
# ---------------------------------------------------------------------------

def is_failed_login(line: str) -> bool:
    """Filtr: czy linia dotyczy nieudanego logowania hasłem (bez parsowania pól)."""
    return FAILED_MARKER in line


def parse_failed_login(line: str) -> tuple[dict | None, str | None]:
    """
    Parsuje linię, która przeszła filtr.
    Zwraca (rekord, None) przy sukcesie albo (None, powód_błędu).
    """
    match = FAILED_LOGIN_RE.search(line)
    if not match:                      # sprawdzamy dopasowanie PRZED użyciem grupy
        return None, "no_ip_pattern"

    ip_candidate = match.group("ip")
    try:
        # Regex dał tylko kandydata (np. 999.1.1.1 też pasuje) — walidujemy osobno.
        ip = str(ipaddress.IPv4Address(ip_candidate))
    except ValueError:
        return None, "invalid_ip_value"

    header = HEADER_RE.match(line)
    return {
        "timestamp": header.group("timestamp") if header else None,
        "user": match.group("user"),
        "invalid_user": match.group("invalid") is not None,
        "source_ip": ip,
        "port": int(match.group("port")),
    }, None


def analyze_log(path: Path) -> AnalysisResult:
    """Główna pętla: filtr -> parsowanie -> agregacja per IP."""
    result = AnalysisResult(source_file=display_path(path))

    for line_number, line in iter_lines(path):
        result.lines_analyzed += 1

        if not is_failed_login(line):
            result.lines_skipped += 1
            accepted = ACCEPTED_RE.search(line)
            if accepted:
                result.successful_logins[accepted.group("ip")] += 1
            continue

        result.lines_matched_filter += 1
        record, error = parse_failed_login(line)
        if record is None:
            result.lines_parse_errors += 1
            result.parse_error_reasons[error] += 1
            if len(result.parse_error_samples) < MAX_ERROR_SAMPLES:
                result.parse_error_samples.append({
                    "line_number": line_number,
                    "reason": error,
                    "excerpt": line[:MAX_EXCERPT_LEN],
                })
            continue

        result.lines_parsed_ok += 1
        stats = result.per_ip.setdefault(record["source_ip"], IpStats())
        stats.failed_logins += 1
        stats.invalid_user_attempts += int(record["invalid_user"])
        stats.users[record["user"]] += 1
        if stats.first_seen is None:
            stats.first_seen = record["timestamp"]
        stats.last_seen = record["timestamp"]

    return result


def filter_only(path: Path) -> dict:
    """Część 3 — sam filtr, bez parsowania pól (do sprawdzenia, czy filtr działa)."""
    analyzed = matched = 0
    for _, line in iter_lines(path):
        analyzed += 1
        if is_failed_login(line):
            matched += 1
    return {
        "lines_analyzed": analyzed,
        "lines_matched_filter": matched,
        "lines_not_matched": analyzed - matched,
    }


# ---------------------------------------------------------------------------
# Część 5 — zliczanie i próg
# ---------------------------------------------------------------------------

def ip_sort_key(ip: str):
    return ipaddress.ip_address(ip)


def ranked_ips(per_ip: dict) -> list[tuple[str, IpStats]]:
    """Sortowanie malejąco po liczbie prób; remisy rozstrzyga numer IP (stabilny wynik)."""
    return sorted(
        per_ip.items(),
        key=lambda item: (-item[1].failed_logins, ip_sort_key(item[0])),
    )


def exceeds_threshold(count: int, threshold: int) -> bool:
    """Alert, gdy liczba prób PRZEKRACZA próg (count > threshold)."""
    return count > threshold


# ---------------------------------------------------------------------------
# Część 8 — IOC
# ---------------------------------------------------------------------------

def load_ioc(path: Path) -> tuple[set[str], list[str]]:
    """Wczytuje listę IOC: pomija puste linie i komentarze, normalizuje adresy."""
    validate_input_file(path)
    iocs: set[str] = set()
    invalid: list[str] = []
    for _, raw in iter_lines(path):
        value = raw.split("#", 1)[0].strip()
        if not value:
            continue
        try:
            iocs.add(str(ipaddress.ip_address(value)))
        except ValueError:
            invalid.append(value)
    return iocs, invalid


def classify(alert: bool, ioc_match: bool) -> str:
    if alert and ioc_match:
        return "threshold_and_ioc"
    if alert:
        return "threshold_only"
    if ioc_match:
        return "ioc_only"
    return "none"


# ---------------------------------------------------------------------------
# Część 6 i 7 — raporty
# ---------------------------------------------------------------------------

def build_report(
    result: AnalysisResult,
    threshold: int,
    iocs: set[str] | None,
    ioc_path: Path | None,
    invalid_iocs: list[str],
    source_sha256: str,
) -> dict:
    rows = []
    for ip, stats in ranked_ips(result.per_ip):
        alert = exceeds_threshold(stats.failed_logins, threshold)
        ioc_match = bool(iocs) and ip in iocs
        rows.append({
            "source_ip": ip,
            "failed_logins": stats.failed_logins,
            "alert": alert,
            "ioc_match": ioc_match,
            "category": classify(alert, ioc_match),
            "invalid_user_attempts": stats.invalid_user_attempts,
            "distinct_usernames": len(stats.users),
            "top_usernames": [u for u, _ in stats.users.most_common(5)],
            "successful_logins_same_ip": result.successful_logins.get(ip, 0),
            "first_seen": stats.first_seen,
            "last_seen": stats.last_seen,
        })

    def ips_in(category: str) -> list[str]:
        return [r["source_ip"] for r in rows if r["category"] == category]

    observed = set(result.per_ip)
    consistent = (
        result.lines_analyzed == result.lines_matched_filter + result.lines_skipped
        and result.lines_matched_filter == result.lines_parsed_ok + result.lines_parse_errors
    )

    return {
        "report": "SSH failed password summary",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source_file": result.source_file,
        "source_sha256": source_sha256,
        "detection": {
            "filter": FAILED_MARKER,
            "ip_regex": FAILED_LOGIN_RE.pattern,
            "threshold": threshold,
            "alert_rule": "failed_logins > threshold",
        },
        "stats": {
            "lines_analyzed": result.lines_analyzed,
            "lines_matched_failed_password": result.lines_matched_filter,
            "lines_parsed_ok": result.lines_parsed_ok,
            "lines_parse_errors": result.lines_parse_errors,
            "lines_skipped": result.lines_skipped,
            "unique_source_ips": len(rows),
            "ips_over_threshold": sum(r["alert"] for r in rows),
            "ips_on_ioc_list": sum(r["ioc_match"] for r in rows),
            "counters_consistent": consistent,
        },
        "parse_errors": {
            "by_reason": dict(result.parse_error_reasons),
            "samples": result.parse_error_samples,
        },
        "ioc": {
            "enabled": iocs is not None,
            "ioc_file": display_path(ioc_path) if ioc_path else None,
            "entries_loaded": len(iocs) if iocs is not None else 0,
            "invalid_entries": invalid_iocs,
            "matched_ips": sorted(observed & iocs, key=ip_sort_key) if iocs else [],
            "not_observed_in_log": sorted(iocs - observed, key=ip_sort_key) if iocs else [],
        },
        "summary": {
            "threshold_only": ips_in("threshold_only"),
            "ioc_only": ips_in("ioc_only"),
            "threshold_and_ioc": ips_in("threshold_and_ioc"),
        },
        "results": rows,
        "note": DISCLAIMER,
    }


def ensure_not_source(target: Path, source: Path) -> None:
    """Zabezpieczenie: raport nigdy nie może nadpisać pliku źródłowego."""
    if target.resolve() == source.resolve():
        raise InputFileError(f"Ścieżka raportu wskazuje na plik źródłowy: {target}")


def write_json(report: dict, path: Path) -> None:
    with path.open("w", encoding=ENCODING) as handle:
        json.dump(report, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


CSV_FIELDS = ["source_ip", "failed_logins", "alert", "ioc_match", "category"]


def write_csv(rows: list[dict], path: Path) -> None:
    """Jeden wiersz per IP, bez pełnych linii logu."""
    with path.open("w", encoding=ENCODING, newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


# ---------------------------------------------------------------------------
# Wyjście na konsolę
# ---------------------------------------------------------------------------

def print_summary(report: dict, top: int) -> None:
    s = report["stats"]
    print(f"Plik:                               {report['source_file']}")
    print(f"Próg alarmowy (alert gdy > próg):   {report['detection']['threshold']}")
    print(f"Linie przeanalizowane:              {s['lines_analyzed']}")
    print(f"Linie 'Failed password':            {s['lines_matched_failed_password']}")
    print(f"  - poprawnie sparsowane (IP):      {s['lines_parsed_ok']}")
    print(f"  - błąd parsowania:                {s['lines_parse_errors']}")
    print(f"Linie pominięte (poza filtrem):     {s['lines_skipped']}")
    print(f"Unikalne IP:                        {s['unique_source_ips']}")
    print(f"IP powyżej progu:                   {s['ips_over_threshold']}")
    if report["ioc"]["enabled"]:
        print(f"IP na liście IOC:                   {s['ips_on_ioc_list']}")

    rows = report["results"][:top]
    if rows:
        print(f"\nTOP {len(rows)} źródłowych IP:")
        print(f"{'IP':<18}{'próby':>7}  {'alert':<6}{'IOC':<5}kategoria")
        for r in rows:
            print(
                f"{r['source_ip']:<18}{r['failed_logins']:>7}  "
                f"{'TAK' if r['alert'] else 'nie':<6}"
                f"{'TAK' if r['ioc_match'] else 'nie':<5}{r['category']}"
            )
    else:
        print("\nBrak dopasowań 'Failed password' z poprawnym IP.")
    print(f"\nUwaga: {report['note']}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Wykrywanie wielu nieudanych logowań SSH z jednego IP (lab 20)."
    )
    parser.add_argument("-i", "--input", type=Path, default=DEFAULT_INPUT,
                        help="plik logu SSH (domyślnie data/auth-sample.log)")
    parser.add_argument("-t", "--threshold", type=int, default=DEFAULT_THRESHOLD,
                        help="próg alarmowy; alert gdy liczba prób > próg (domyślnie 3)")
    parser.add_argument("-o", "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR,
                        help="katalog na raporty (domyślnie output/)")
    parser.add_argument("--ioc", type=Path, default=DEFAULT_IOC,
                        help="lista IOC, jedno IP w linii (domyślnie data/ioc-ips.txt)")
    parser.add_argument("--no-ioc", action="store_true", help="pomiń porównanie z IOC")
    parser.add_argument("--no-csv", action="store_true", help="nie zapisuj raportu CSV")
    parser.add_argument("--top", type=int, default=DEFAULT_TOP,
                        help="ile adresów pokazać w TOP (domyślnie 10)")
    parser.add_argument("--filter-only", action="store_true",
                        help="tylko policz linie pasujące do filtra (część 3)")
    args = parser.parse_args(argv)
    if args.threshold < 0:
        parser.error("próg nie może być ujemny")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        input_path = validate_input_file(args.input)

        if args.filter_only:
            counts = filter_only(input_path)
            print(json.dumps(counts, indent=2, ensure_ascii=False))
            return 0

        iocs, invalid_iocs, ioc_path = None, [], None
        if not args.no_ioc:
            ioc_path = args.ioc
            iocs, invalid_iocs = load_ioc(ioc_path)
            if invalid_iocs:
                print(f"Ostrzeżenie: pominięto niepoprawne wpisy IOC: {invalid_iocs}",
                      file=sys.stderr)

        hash_before = sha256_of_file(input_path)
        result = analyze_log(input_path)
        report = build_report(result, args.threshold, iocs, ioc_path,
                              invalid_iocs, hash_before)

        args.output_dir.mkdir(parents=True, exist_ok=True)
        json_path = args.output_dir / JSON_NAME
        ensure_not_source(json_path, input_path)
        write_json(report, json_path)

        csv_path = None
        if not args.no_csv:
            csv_path = args.output_dir / CSV_NAME
            ensure_not_source(csv_path, input_path)
            write_csv(report["results"], csv_path)

        if sha256_of_file(input_path) != hash_before:  # kontrola integralności źródła
            print("Ostrzeżenie: plik źródłowy zmienił się w trakcie analizy!",
                  file=sys.stderr)

    except InputFileError as exc:
        print(f"Błąd: {exc}", file=sys.stderr)
        return 2

    print_summary(report, args.top)
    print(f"\nRaport JSON: {display_path(json_path)}")
    if csv_path:
        print(f"Raport CSV:  {display_path(csv_path)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
