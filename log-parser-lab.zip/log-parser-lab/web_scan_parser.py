#!/usr/bin/env python3
"""
web_scan_parser.py — Lab 20, część 10 (bonus): prosta analiza web scanning.

Czyta log Apache/Nginx w formacie Combined Log linia po linii, wyciąga IP,
metodę HTTP, ścieżkę, kod statusu i user-agent, zlicza odpowiedzi 404 per IP,
oznacza IP z dużą liczbą 404 i przygotowuje TOP ścieżek zwracających 404.

To osobny parser: format logu webowego jest zupełnie inny niż auth.log,
więc inny jest regex i inne są pola. Wspólne są tylko funkcje do bezpiecznego
odczytu pliku (pathlib, kontrola istnienia, czytanie linia po linii).

Przykład:
    python web_scan_parser.py --input data/apache-sample.log --threshold 10
"""

from __future__ import annotations

import argparse
import csv
import ipaddress
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from ssh_bruteforce_parser import (
    BASE_DIR,
    ENCODING,
    InputFileError,
    display_path,
    ensure_not_source,
    iter_lines,
    validate_input_file,
)

DEFAULT_INPUT = BASE_DIR / "data" / "apache-sample.log"
DEFAULT_OUTPUT_DIR = BASE_DIR / "output"
JSON_NAME = "web-404-summary.json"
CSV_NAME = "web-404-per-ip.csv"
DEFAULT_THRESHOLD = 10
DEFAULT_TOP = 10

# Combined Log Format:
# IP ident user [timestamp] "METHOD PATH PROTOCOL" STATUS SIZE "REFERER" "USER-AGENT"
COMBINED_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<timestamp>[^\]]+)\] '
    r'"(?P<method>[A-Z]+) (?P<path>\S+) (?P<protocol>[^"]+)" '
    r'(?P<status>\d{3}) (?P<size>\d+|-) '
    r'"(?P<referer>[^"]*)" "(?P<user_agent>[^"]*)"'
)

# Fragmenty user-agenta typowe dla narzędzi/skryptów, a nie przeglądarek.
# To heurystyka — user-agent jest w pełni kontrolowany przez klienta.
TOOL_UA_MARKERS = (
    "curl", "wget", "python-requests", "python-urllib", "go-http-client",
    "sqlmap", "nikto", "nmap", "masscan", "zgrab", "gobuster", "dirbuster",
    "ffuf", "wpscan", "nuclei", "httpclient", "libwww-perl",
)

DISCLAIMER = (
    "Duża liczba odpowiedzi 404 z jednego IP to sygnał możliwego skanowania ścieżek, "
    "a nie potwierdzony incydent. Należy sprawdzić kontekst: rodzaj ścieżek, "
    "user-agent, czas trwania, inne kody odpowiedzi (np. 200 na wrażliwych ścieżkach)."
)


def is_tool_user_agent(user_agent: str) -> bool:
    ua = user_agent.lower()
    return ua in ("", "-") or any(marker in ua for marker in TOOL_UA_MARKERS)


def analyze_web_log(path: Path) -> dict:
    stats = {
        "lines_analyzed": 0,
        "lines_parsed_ok": 0,
        "lines_parse_errors": 0,
        "lines_invalid_ip": 0,
    }
    status_counts: Counter = Counter()
    method_counts: Counter = Counter()
    not_found_per_ip: Counter = Counter()
    requests_per_ip: Counter = Counter()
    not_found_paths: Counter = Counter()
    user_agents_per_ip: dict[str, Counter] = defaultdict(Counter)
    not_found_paths_per_ip: dict[str, set] = defaultdict(set)
    error_samples: list[dict] = []

    for line_number, line in iter_lines(path):
        stats["lines_analyzed"] += 1
        match = COMBINED_RE.match(line)
        if not match:
            stats["lines_parse_errors"] += 1
            if len(error_samples) < 10:
                error_samples.append({"line_number": line_number, "excerpt": line[:160]})
            continue
        try:
            ip = str(ipaddress.ip_address(match.group("ip")))
        except ValueError:
            stats["lines_invalid_ip"] += 1
            continue

        stats["lines_parsed_ok"] += 1
        status = match.group("status")
        path_value = match.group("path")          # dokładna ścieżka, z query stringiem
        status_counts[status] += 1
        method_counts[match.group("method")] += 1
        requests_per_ip[ip] += 1
        user_agents_per_ip[ip][match.group("user_agent")] += 1

        if status == "404":
            not_found_per_ip[ip] += 1
            not_found_paths[path_value] += 1
            not_found_paths_per_ip[ip].add(path_value)

    return {
        "stats": stats,
        "status_counts": status_counts,
        "method_counts": method_counts,
        "not_found_per_ip": not_found_per_ip,
        "requests_per_ip": requests_per_ip,
        "not_found_paths": not_found_paths,
        "user_agents_per_ip": user_agents_per_ip,
        "not_found_paths_per_ip": not_found_paths_per_ip,
        "error_samples": error_samples,
    }


def build_report(path: Path, data: dict, threshold: int, top: int) -> dict:
    rows = []
    ranked = sorted(
        data["not_found_per_ip"].items(),
        key=lambda item: (-item[1], ipaddress.ip_address(item[0])),
    )
    for ip, count in ranked:
        total = data["requests_per_ip"][ip]
        uas = data["user_agents_per_ip"][ip]
        main_ua = uas.most_common(1)[0][0]
        rows.append({
            "source_ip": ip,
            "not_found_404": count,
            "total_requests": total,
            "ratio_404": round(count / total, 3),
            "distinct_404_paths": len(data["not_found_paths_per_ip"][ip]),
            "alert": count > threshold,
            "main_user_agent": main_ua,
            "tool_like_user_agent": any(is_tool_user_agent(ua) for ua in uas),
            "user_agents": dict(uas.most_common()),
        })

    return {
        "report": "Web 404 / path scanning summary",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source_file": display_path(path),
        "detection": {
            "threshold_404": threshold,
            "alert_rule": "not_found_404 > threshold_404",
        },
        "stats": {
            **data["stats"],
            "total_404": sum(data["not_found_per_ip"].values()),
            "ips_with_404": len(rows),
            "ips_over_threshold": sum(r["alert"] for r in rows),
        },
        "status_distribution": dict(sorted(data["status_counts"].items())),
        "method_distribution": dict(data["method_counts"].most_common()),
        "top_404_paths": [
            {"path": p, "count": c} for p, c in data["not_found_paths"].most_common(top)
        ],
        "results": rows,
        "parse_error_samples": data["error_samples"],
        "note": DISCLAIMER,
    }


CSV_FIELDS = ["source_ip", "not_found_404", "total_requests", "ratio_404",
              "distinct_404_paths", "alert", "main_user_agent", "tool_like_user_agent"]


def write_outputs(report: dict, output_dir: Path, source: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / JSON_NAME
    csv_path = output_dir / CSV_NAME
    ensure_not_source(json_path, source)
    ensure_not_source(csv_path, source)
    with json_path.open("w", encoding=ENCODING) as handle:
        json.dump(report, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    with csv_path.open("w", encoding=ENCODING, newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(report["results"])
    return json_path, csv_path


def print_summary(report: dict) -> None:
    s = report["stats"]
    print(f"Plik:                     {report['source_file']}")
    print(f"Linie przeanalizowane:    {s['lines_analyzed']}")
    print(f"Linie sparsowane:         {s['lines_parsed_ok']}")
    print(f"Błędy parsowania:         {s['lines_parse_errors']}")
    print(f"Odpowiedzi 404 łącznie:   {s['total_404']}")
    print(f"Próg 404 (alert gdy >):   {report['detection']['threshold_404']}")
    print(f"IP powyżej progu:         {s['ips_over_threshold']}")

    print("\n404 per IP:")
    print(f"{'IP':<18}{'404':>5}{'wszystkie':>11}{'udział':>8}  {'alert':<6}user-agent")
    for r in report["results"]:
        print(f"{r['source_ip']:<18}{r['not_found_404']:>5}{r['total_requests']:>11}"
              f"{r['ratio_404']:>8.0%}  {'TAK' if r['alert'] else 'nie':<6}"
              f"{r['main_user_agent']}")

    print("\nTOP ścieżek zwracających 404:")
    for item in report["top_404_paths"]:
        print(f"{item['count']:>5}  {item['path']}")

    print("\nRozkład statusów HTTP:")
    print("  " + ", ".join(f"{k}: {v}" for k, v in report["status_distribution"].items()))
    print(f"\nUwaga: {report['note']}")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analiza 404 / web scanning (lab 20, bonus).")
    parser.add_argument("-i", "--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("-t", "--threshold", type=int, default=DEFAULT_THRESHOLD,
                        help="alert, gdy liczba 404 z IP > próg (domyślnie 10)")
    parser.add_argument("-o", "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--top", type=int, default=DEFAULT_TOP)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        source = validate_input_file(args.input)
        data = analyze_web_log(source)
        report = build_report(source, data, args.threshold, args.top)
        json_path, csv_path = write_outputs(report, args.output_dir, source)
    except InputFileError as exc:
        print(f"Błąd: {exc}", file=sys.stderr)
        return 2
    print_summary(report)
    print(f"\nRaport JSON: {display_path(json_path)}")
    print(f"Raport CSV:  {display_path(csv_path)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
