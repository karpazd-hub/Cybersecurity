# log-parser-lab — parser logów SSH i IOC (Lab 20)

Narzędzie wykrywa wzorzec wielu nieudanych logowań SSH (`Failed password`) z jednego adresu IP,
zlicza próby per IP, oznacza adresy przekraczające próg, porównuje je z listą IOC i zapisuje
raport JSON oraz CSV. Bonus: osobny parser logu Apache (skanowanie ścieżek, odpowiedzi `404`).

> Wynik jest **sygnałem analitycznym**, a nie automatycznym potwierdzeniem incydentu.

## Struktura

```text
log-parser-lab/
├── data/                        # dane wejściowe (tylko do odczytu)
│   ├── auth-sample.log
│   ├── apache-sample.log
│   └── ioc-ips.txt
├── output/                      # wyłącznie raporty generowane przez skrypty
├── tests/
│   ├── fixtures/                # pusty log i log bez "Failed password"
│   └── test_parsers.py          # 31 testów (unittest)
├── ssh_bruteforce_parser.py     # części 2–8
├── pandas_analysis.py           # część 9 (opcjonalna)
├── web_scan_parser.py           # część 10 (bonus)
├── README.md
├── requirements.txt             # pandas, numpy (tylko dla części 9)
└── requirements-lock.txt        # pip freeze z przetestowanego venv
```

## Uruchomienie

Parsery wymagają tylko Pythona 3.8+ (biblioteka standardowa).

```bash
cd log-parser-lab

# parser SSH z domyślnymi ustawieniami (data/auth-sample.log, próg 3, IOC z data/ioc-ips.txt)
python ssh_bruteforce_parser.py

# jawnie podane parametry
python ssh_bruteforce_parser.py --input data/auth-sample.log --threshold 3 --ioc data/ioc-ips.txt

# tylko sprawdzenie filtra (część 3)
python ssh_bruteforce_parser.py --filter-only

# bez CSV i bez IOC
python ssh_bruteforce_parser.py --no-csv --no-ioc

# bonus: log webowy
python web_scan_parser.py --input data/apache-sample.log --threshold 10
```

Opcje parsera SSH:

| Opcja | Znaczenie | Domyślnie |
|---|---|---|
| `-i`, `--input` | plik logu SSH | `data/auth-sample.log` |
| `-t`, `--threshold` | próg; alert, gdy liczba prób **>** próg | `3` |
| `-o`, `--output-dir` | katalog raportów | `output/` |
| `--ioc` | lista IOC (jedno IP w linii) | `data/ioc-ips.txt` |
| `--no-ioc` | pomija porównanie z IOC | — |
| `--no-csv` | nie zapisuje CSV | — |
| `--top` | liczba adresów w TOP na konsoli | `10` |
| `--filter-only` | tylko liczy linie pasujące do filtra | — |

Kody wyjścia: `0` — sukces, `2` — błąd pliku wejściowego (brak pliku, katalog zamiast pliku,
brak uprawnień, próba zapisu raportu na plik źródłowy) lub niepoprawny argument.

## Analiza pandas (opcjonalna)

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python ssh_bruteforce_parser.py
python pandas_analysis.py
```

## Testy

```bash
python -m unittest discover -s tests -v
```

## Raporty w `output/`

| Plik | Zawartość |
|---|---|
| `ssh-bruteforce-summary.json` | pełny raport SSH: liczniki linii, próg, wyniki per IP, alerty, IOC, błędy parsowania, SHA-256 źródła, zastrzeżenie |
| `ssh-bruteforce-summary.csv` | `source_ip,failed_logins,alert,ioc_match,category` — jeden wiersz per IP |
| `ssh-bruteforce-alerts.csv` | tylko IP z alertem (z `pandas_analysis.py`) |
| `web-404-summary.json` | bonus: 404 per IP, TOP ścieżek 404, rozkład statusów, user-agenty |
| `web-404-per-ip.csv` | bonus: jeden wiersz per IP z odpowiedziami 404 |

## Wyniki na danych testowych (próg 3)

500 linii, 402 z `Failed password`, 399 poprawnie sparsowanych, 3 błędy parsowania, 98 pominiętych,
13 unikalnych IP, 7 IP w alercie, 2 IP na liście IOC (`203.0.113.10`, `203.0.113.77`) —
zgodnie z `expected-results.md`.

## Ograniczenia

- Wzorzec IP obsługuje IPv4; linie z IPv6 trafią do błędów parsowania (`no_ip_pattern`).
- Klasyczny syslog nie zapisuje roku, dlatego `first_seen`/`last_seen` to timestampy w postaci z logu.
- Próg jest liczony dla całego pliku, bez okna czasowego.
