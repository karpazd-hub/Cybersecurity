# Lab 20 — Python cz. 3: parser logów i IOC — zadania i rozwiązania

Każda sekcja zawiera najpierw treść zadania z `README.md` (w cytacie), a pod nią rozwiązanie.
Pełny kod jest w plikach projektu:

| Plik | Część |
|---|---|
| `ssh_bruteforce_parser.py` | 2–8 (odczyt, filtr, regex, zliczanie, próg, JSON, CSV, IOC) |
| `pandas_analysis.py` | 9 (pandas) |
| `web_scan_parser.py` | 10 (bonus: Apache/Nginx) |
| `tests/test_parsers.py` | 11 (31 testów, wszystkie przechodzą) |

**Wynik w skrócie (próg 3):** 500 linii, 402 z `Failed password`, 399 poprawnie sparsowanych,
3 błędy parsowania, 98 linii pominiętych, 13 unikalnych IP, **7 IP w alercie**,
2 IP z listy IOC (`203.0.113.10`, `203.0.113.77`), oba także powyżej progu.
Wszystkie liczby zgadzają się z `materials/expected-results.md`.

---

## Część 1 — przygotowanie środowiska

> Wykonaj:
>
> 1. Utwórz katalog projektu `log-parser-lab`.
> 2. Utwórz podkatalogi `data/` i `output/`.
> 3. Skopiuj materiały testowe do `data/`.
> 4. Utwórz plik `ssh_bruteforce_parser.py`.
> 5. Utwórz plik `README.md`.
> 6. Utwórz plik `requirements.txt`.
> 7. Jeśli używasz `pandas`, pracuj w środowisku `venv` i zapisz zależności.
>
> Kryteria akceptacji:
>
> - projekt ma czytelną strukturę,
> - dane wejściowe są oddzielone od wyników,
> - katalog `output/` jest przeznaczony wyłącznie na raporty,
> - plik źródłowy logu nie będzie modyfikowany.

### Rozwiązanie

Rozpakowanie materiałów (archiwa zawierają też katalogi `__MACOSX/` z metadanymi macOS — należy je pominąć):

```bash
unzip materials.zip -d /tmp/lab20
unzip references.zip -d /tmp/lab20

mkdir -p log-parser-lab/{data,output,tests/fixtures}
cp /tmp/lab20/materials/{auth-sample.log,apache-sample.log,ioc-ips.txt} log-parser-lab/data/
cd log-parser-lab
touch ssh_bruteforce_parser.py README.md requirements.txt

# venv dla części 9
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
python -m pip install pandas numpy
python -m pip freeze > requirements-lock.txt
```

Struktura końcowa:

```text
log-parser-lab/
├── data/                        # wejście — tylko do odczytu
│   ├── auth-sample.log
│   ├── apache-sample.log
│   └── ioc-ips.txt
├── output/                      # wyłącznie raporty generowane przez skrypty
├── tests/
│   ├── fixtures/empty.log       # pusty plik do testów
│   ├── fixtures/no-failed.log   # log bez "Failed password"
│   └── test_parsers.py
├── ssh_bruteforce_parser.py
├── pandas_analysis.py
├── web_scan_parser.py
├── README.md
├── requirements.txt             # pandas>=2.0, numpy>=1.24
└── requirements-lock.txt        # dokładne wersje z pip freeze
```

Jak spełniono kryteria akceptacji:

- **Czytelna struktura:** osobny plik dla każdego narzędzia, testy w `tests/`, dokumentacja w `README.md`.
- **Wejście oddzielone od wyników:** dane tylko w `data/`, raporty tylko w `output/`.
- **`output/` tylko na raporty:** skrypty zapisują wyłącznie tam (`--output-dir`, domyślnie `output/`).
- **Źródło niemodyfikowane:** plik otwierany w trybie `"r"`, SHA-256 liczony przed i po analizie
  i zapisywany w raporcie. Dodatkowo parser odmawia zapisu raportu, jeśli ścieżka raportu wskazuje
  na plik źródłowy.

`requirements.txt` zawiera tylko bezpośrednie zależności (`pandas`, `numpy`), a `requirements-lock.txt`
dokładne wersje z przetestowanego środowiska (pandas 3.1.0, numpy 2.5.4, Python 3.13).
Same parsery korzystają wyłącznie z biblioteki standardowej.

---

## Część 2 — odczyt pliku

> Zaimplementuj odczyt pliku SSH.
>
> Wymagania:
>
> 1. Użyj ścieżek przez `pathlib`.
> 2. Sprawdź, czy plik wejściowy istnieje.
> 3. Sprawdź, czy ścieżka wejściowa jest plikiem.
> 4. Otwórz plik z jawnym kodowaniem.
> 5. Czytaj plik linia po linii.
> 6. Dodaj licznik wszystkich przeanalizowanych linii.
> 7. Obsłuż brak pliku czytelnym komunikatem.
> 8. Nie używaj odczytu całego pliku do pamięci jako podstawowego rozwiązania.
>
> Test:
>
> - uruchom parser na `data/auth-sample.log`,
> - uruchom parser na nieistniejącej ścieżce,
> - uruchom parser na katalogu zamiast pliku.

### Rozwiązanie

```python
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_INPUT = BASE_DIR / "data" / "auth-sample.log"      # 1. pathlib
ENCODING = "utf-8"


class InputFileError(Exception):
    """Czytelny błąd dotyczący pliku wejściowego."""


def validate_input_file(path: Path) -> Path:
    if not path.exists():                                     # 2. czy istnieje
        raise InputFileError(f"Plik wejściowy nie istnieje: {path}")
    if not path.is_file():                                    # 3. czy to plik
        raise InputFileError(
            f"Ścieżka wejściowa nie jest plikiem (np. jest katalogiem): {path}")
    return path


def iter_lines(path: Path):
    """Generator — zwraca kolejne linie, nie trzyma całego pliku w pamięci."""
    try:
        with path.open("r", encoding=ENCODING, errors="replace") as handle:   # 4.
            for line_number, line in enumerate(handle, start=1):              # 5.
                yield line_number, line.rstrip("\r\n")
    except PermissionError as exc:
        raise InputFileError(f"Brak uprawnień do odczytu pliku: {path}") from exc
```

W pętli analizy `result.lines_analyzed += 1` jest zwiększane dla każdej linii (wymaganie 6).
W `main()` wyjątek `InputFileError` jest łapany i zamieniany na komunikat na `stderr` oraz kod wyjścia `2`,
bez tracebacku (wymaganie 7). Iteracja po obiekcie pliku zamiast `read()`/`readlines()`
oznacza, że w pamięci jest naraz jedna linia (wymaganie 8).

`errors="replace"` sprawia, że pojedynczy uszkodzony bajt w logu nie przerywa analizy:
zostaje zastąpiony znakiem `�`, a parser idzie dalej.

**Wyniki testów:**

```text
$ python ssh_bruteforce_parser.py --input data/auth-sample.log
Linie przeanalizowane:              500
...
Raport JSON: output/ssh-bruteforce-summary.json

$ python ssh_bruteforce_parser.py -i data/nie-ma-takiego.log
Błąd: Plik wejściowy nie istnieje: data/nie-ma-takiego.log          (kod wyjścia 2)

$ python ssh_bruteforce_parser.py -i data
Błąd: Ścieżka wejściowa nie jest plikiem (np. jest katalogiem): data (kod wyjścia 2)
```

---

## Część 3 — filtr zdarzeń SSH

> Dodaj filtr wybierający linie związane z nieudanym logowaniem SSH.
>
> Wymagania:
>
> 1. Zidentyfikuj tekst charakterystyczny dla nieudanego logowania.
> 2. Zlicz liczbę linii pasujących do tego filtra.
> 3. Nie parsuj jeszcze wszystkich pól — najpierw upewnij się, że filtr działa.
> 4. Dodaj licznik linii niepasujących.
>
> Kryteria akceptacji:
>
> - parser odróżnia linie `Failed password` od pozostałych,
> - parser nie kończy pracy na liniach innego typu,
> - raport końcowy zawiera liczbę linii przeanalizowanych i dopasowanych.

### Rozwiązanie

Najpierw sprawdziłem, jakie typy komunikatów są w `auth-sample.log` (po zamianie IP, portów i nazw
użytkowników na symbole):

| Typ komunikatu | Liczba |
|---|---:|
| `Failed password for invalid user X from IP port N ssh2` | 284 |
| `Failed password for X from IP port N ssh2` | 115 |
| `Failed password ...` w złym formacie (bez IP) | 3 |
| `Accepted password` / `Accepted publickey` | 14 / 7 |
| `pam_unix(...)` session opened/closed, CRON | 68 |
| `Invalid user ...`, `Connection closed ...`, `sudo` | 9 |

Tekstem charakterystycznym jest **`Failed password`**:

- nie samo `Failed`, bo to obejmowałoby też np. `Failed publickey` (inny mechanizm uwierzytelnienia),
- nie `Invalid user`, bo próba na nieistniejące konto generuje *dwie* linie
  (`Invalid user git from ...` oraz `Failed password for invalid user git from ...`) i liczylibyśmy ją podwójnie.

```python
FAILED_MARKER = "Failed password"

def is_failed_login(line: str) -> bool:
    """Filtr: decyzja tak/nie, bez parsowania pól."""
    return FAILED_MARKER in line


def filter_only(path: Path) -> dict:
    analyzed = matched = 0
    for _, line in iter_lines(path):
        analyzed += 1
        if is_failed_login(line):
            matched += 1
    return {"lines_analyzed": analyzed,
            "lines_matched_filter": matched,
            "lines_not_matched": analyzed - matched}
```

Tryb `--filter-only` uruchamia sam filtr, bez parsowania pól (wymaganie 3):

```text
$ python ssh_bruteforce_parser.py --filter-only
{
  "lines_analyzed": 500,
  "lines_matched_filter": 402,
  "lines_not_matched": 98
}
```

Linie innego typu trafiają do licznika `lines_skipped` i pętla idzie dalej (`continue`),
więc parser nie kończy pracy na nietypowych liniach. Raport końcowy zawiera
`lines_analyzed` i `lines_matched_failed_password`.

---

## Część 4 — ekstrakcja adresu IP

> Dodaj regex do wyciągania źródłowego adresu IP z linii nieudanego logowania.
>
> Wymagania:
>
> 1. Użyj modułu `re`.
> 2. Zapisz regex jako raw string.
> 3. Użyj grupy przechwytującej dla adresu IP.
> 4. Sprawdź, czy dopasowanie istnieje przed użyciem grupy.
> 5. Zlicz linie, które zawierały interesujący komunikat, ale nie pasowały do wzorca.
> 6. Traktuj wynik regexa jako kandydata na IP, nie jako pełną walidację adresu.
>
> Testy pozytywne:
>
> - linia z `Failed password for root from ...`,
> - linia z `Failed password for invalid user ... from ...`.
>
> Testy negatywne:
>
> - linia z poprawnym logowaniem,
> - linia bez IP,
> - linia z innym komunikatem SSH.

### Rozwiązanie

```python
import re, ipaddress

FAILED_LOGIN_RE = re.compile(                                    # 1. moduł re
    r"Failed password for (?P<invalid>invalid user )?(?P<user>\S*) "   # 2. raw string
    r"from (?P<ip>\d{1,3}(?:\.\d{1,3}){3}) port (?P<port>\d+)"         # 3. grupa "ip"
)

HEADER_RE = re.compile(          # opcjonalnie: timestamp (syslog lub ISO 8601)
    r"^(?P<timestamp>[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}"
    r"|\d{4}-\d{2}-\d{2}T\S+)\s+(?P<host>\S+)\s+"
)


def parse_failed_login(line: str):
    match = FAILED_LOGIN_RE.search(line)
    if not match:                                  # 4. najpierw sprawdzenie dopasowania
        return None, "no_ip_pattern"

    ip_candidate = match.group("ip")
    try:                                           # 6. regex = kandydat, walidacja osobno
        ip = str(ipaddress.IPv4Address(ip_candidate))
    except ValueError:
        return None, "invalid_ip_value"

    header = HEADER_RE.match(line)
    return {
        "timestamp": header.group("timestamp") if header else None,
        "user": match.group("user"),
        "invalid_user": match.group("invalid") is not None,
        "source_ip": ip,
        "port": int(match.group("port")),
    }, None
```

Elementy wzorca:

| Fragment | Znaczenie |
|---|---|
| `(?P<invalid>invalid user )?` | opcjonalny dopisek dla nieistniejącego konta |
| `(?P<user>\S*)` | nazwa użytkownika; `*` zamiast `+`, bo sshd potrafi zalogować pustą nazwę |
| `(?P<ip>\d{1,3}(?:\.\d{1,3}){3})` | **grupa przechwytująca** z kandydatem na IPv4 |
| `(?:...)` | grupa nieprzechwytująca, służy tylko do powtórzenia `{3}` |
| `port (?P<port>\d+)` | kotwica kontekstu: IP musi stać między `from` a `port` |

W pętli analizy linie, które przeszły filtr, ale nie wzorzec, zwiększają `lines_parse_errors`
i licznik powodu (`no_ip_pattern` albo `invalid_ip_value`). Pierwsze 10 przypadków trafia do raportu
z numerem linii (wymaganie 5). W danych testowych są dokładnie 3 takie linie (19, 489, 496):

```text
Jul 24 10:08:00 labhost sshd[1018]: Failed password for root from not-an-ip port 62001 ssh2
Jul 24 11:40:00 labhost sshd[2411]: Failed password for root from unknown port 62002 ssh2
Jul 24 11:45:00 labhost sshd[2412]: Failed password unexpected format
```

Testy (`tests/test_parsers.py`, klasa `TestFilterAndRegex`):

| Test | Linia | Wynik |
|---|---|---|
| pozytywny | `Failed password for root from 203.0.113.10 port 51234` | IP `203.0.113.10`, user `root` ✅ |
| pozytywny | `Failed password for invalid user admin from 203.0.113.10 ...` | IP `203.0.113.10`, user `admin`, `invalid_user=True` ✅ |
| negatywny | `Accepted password for student from 192.0.2.15 ...` | nie przechodzi filtra ✅ |
| negatywny | `Failed password for root from not-an-ip ...` (i 2 inne) | filtr TAK, wzorzec NIE → `no_ip_pattern` ✅ |
| negatywny | `Invalid user git from ...`, `Connection closed by ...` | nie przechodzi filtra ✅ |
| kandydat ≠ IP | `... from 999.300.1.1 port 1` | regex pasuje, `ipaddress` odrzuca → `invalid_ip_value` ✅ |
| inny format | ISO timestamp + `sshd-session` + pusta nazwa użytkownika | IP poprawnie wyciągnięte ✅ |

---

## Część 5 — zliczanie prób per IP

> Dodaj agregację nieudanych logowań per IP.
>
> Wymagania:
>
> 1. Zlicz liczbę nieudanych prób dla każdego adresu IP.
> 2. Posortuj wynik malejąco po liczbie prób.
> 3. Pokaż TOP adresów źródłowych.
> 4. Dodaj próg alarmowy.
> 5. Oznacz adresy IP przekraczające próg.
>
> Domyślny próg dla danych testowych: `3`
>
> W realnym środowisku próg powinien być dobrany do skali systemu i normalnego tła logowań.

### Rozwiązanie

```python
@dataclass
class IpStats:
    failed_logins: int = 0
    invalid_user_attempts: int = 0
    users: Counter = field(default_factory=Counter)
    first_seen: str | None = None
    last_seen: str | None = None

# w analyze_log() — 1. zliczanie
stats = result.per_ip.setdefault(record["source_ip"], IpStats())
stats.failed_logins += 1
stats.users[record["user"]] += 1


def ranked_ips(per_ip):                                     # 2. sortowanie malejąco
    return sorted(per_ip.items(),
                  key=lambda item: (-item[1].failed_logins, ipaddress.ip_address(item[0])))


def exceeds_threshold(count: int, threshold: int) -> bool:  # 4–5. próg
    return count > threshold          # „przekracza” = ściśle większe
```

Zamiast samego `Counter` używam małej klasy `IpStats`, bo poza liczbą prób zbieram kontekst:
użytkowników, liczbę prób na nieistniejące konta, pierwsze i ostatnie wystąpienie.
Przy remisie sortuję po adresie IP, więc raport jest zawsze w tej samej kolejności.
Próg ustawia `--threshold` (domyślnie 3), a `--top N` (domyślnie 10) decyduje, ile adresów pokazać.

Wynik (`python ssh_bruteforce_parser.py --top 13`):

| IP | Nieudane | Alert (>3) | Prób na nieistn. konta | Użytkownicy | Okno czasowe |
|---|---:|:---:|---:|---|---|
| `203.0.113.77` | 155 | **TAK** | 118 | backup, admin, root, test | 10:06:01–10:18:58 |
| `203.0.113.10` | 124 | **TAK** | 92 | root, admin, oracle, postgres, test | 10:00:01–10:25:57 |
| `198.51.100.61` | 45 | **TAK** | 30 | git, deploy, root | 10:30:00–10:33:40 |
| `203.0.113.88` | 32 | **TAK** | 32 | git, test, guest | 10:40:00–10:45:10 |
| `192.0.2.120` | 18 | **TAK** | 0 | deploy | 10:50:00–11:07:00 |
| `198.51.100.90` | 9 | **TAK** | 6 | ubuntu, centos, root | 10:55:00–10:57:00 |
| `192.0.2.200` | 4 | **TAK** | 4 | service | 11:10:00–11:10:21 |
| `192.0.2.31` | 3 | nie | 0 | student | 11:12:00–11:12:22 |
| `198.51.100.23` | 3 | nie | 1 | root, oracle | 10:02:01–10:02:08 |
| `192.0.2.55` | 2 | nie | 0 | deploy | 10:04:01–10:04:04 |
| `198.51.100.112` | 2 | nie | 0 | analyst | 11:15:00–11:15:08 |
| `192.0.2.42` | 1 | nie | 0 | student | 11:18:00 |
| `203.0.113.130` | 1 | nie | 1 | support | 11:20:00 |

**7 IP w alercie**, zgodnie z oczekiwanymi wynikami. Zachowane są przypadki graniczne:
4 próby dają alert, 3 próby nie.

Uwagi analityczne:

- `203.0.113.77` i `203.0.113.10` to klasyczny wzorzec słownikowy: wiele kont, głównie nieistniejących,
  ponad 100 prób w kilkanaście–kilkadziesiąt minut.
- `192.0.2.120` próbuje tylko konta `deploy` (18 razy przez 17 minut). Może to być atak na jedno
  konto, ale też np. skrypt CI ze starym hasłem. Sam próg tych sytuacji nie rozróżni.

---

## Część 6 — raport JSON

> Zapisz wynik do JSON.
>
> Raport powinien zawierać:
>
> - nazwę lub ścieżkę analizowanego pliku,
> - próg alarmowy,
> - liczbę przeanalizowanych linii,
> - liczbę linii pasujących do nieudanego logowania,
> - liczbę linii pominiętych,
> - liczbę linii z błędem parsowania,
> - listę adresów IP i liczby prób,
> - informację, które IP przekroczyły próg,
> - krótką informację, że wynik jest sygnałem analitycznym, nie automatycznym potwierdzeniem incydentu.
>
> Zapisz raport w katalogu `output/`, na przykład: `output/ssh-bruteforce-summary.json`

### Rozwiązanie

```python
def write_json(report: dict, path: Path) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2, ensure_ascii=False)
        handle.write("\n")

# w main():
args.output_dir.mkdir(parents=True, exist_ok=True)
json_path = args.output_dir / "ssh-bruteforce-summary.json"
ensure_not_source(json_path, input_path)     # raport nigdy nie nadpisze logu
write_json(report, json_path)
```

Fragment wygenerowanego `output/ssh-bruteforce-summary.json` (`"..."` oznacza skrócone listy):

```json
{
  "report": "SSH failed password summary",
  "generated_at": "2026-10-25T22:45:23+00:00",
  "source_file": "data/auth-sample.log",
  "source_sha256": "fc75607be94fd208890b5f717f07231bae31accce190ca87e6c4300a614f9244",
  "detection": {
    "filter": "Failed password",
    "ip_regex": "Failed password for (?P<invalid>invalid user )?(?P<user>\\S*) from (?P<ip>\\d{1,3}(?:\\.\\d{1,3}){3}) port (?P<port>\\d+)",
    "threshold": 3,
    "alert_rule": "failed_logins > threshold"
  },
  "stats": {
    "lines_analyzed": 500,
    "lines_matched_failed_password": 402,
    "lines_parsed_ok": 399,
    "lines_parse_errors": 3,
    "lines_skipped": 98,
    "unique_source_ips": 13,
    "ips_over_threshold": 7,
    "ips_on_ioc_list": 2,
    "counters_consistent": true
  },
  "parse_errors": {
    "by_reason": { "no_ip_pattern": 3 },
    "samples": [
      { "line_number": 19, "reason": "no_ip_pattern",
        "excerpt": "Jul 24 10:08:00 labhost sshd[1018]: Failed password for root from not-an-ip port 62001 ssh2" },
      "..."
    ]
  },
  "ioc": {
    "enabled": true,
    "ioc_file": "data/ioc-ips.txt",
    "entries_loaded": 3,
    "invalid_entries": [],
    "matched_ips": ["203.0.113.10", "203.0.113.77"],
    "not_observed_in_log": ["198.51.100.50"]
  },
  "summary": {
    "threshold_only": ["198.51.100.61", "203.0.113.88", "192.0.2.120", "198.51.100.90", "192.0.2.200"],
    "ioc_only": [],
    "threshold_and_ioc": ["203.0.113.77", "203.0.113.10"]
  },
  "results": [
    {
      "source_ip": "203.0.113.77",
      "failed_logins": 155,
      "alert": true,
      "ioc_match": true,
      "category": "threshold_and_ioc",
      "invalid_user_attempts": 118,
      "distinct_usernames": 4,
      "top_usernames": ["backup", "admin", "root", "test"],
      "successful_logins_same_ip": 0,
      "first_seen": "Jul 24 10:06:01",
      "last_seen": "Jul 24 10:18:58"
    },
    "..."
  ],
  "note": "Wynik jest sygnałem analitycznym, a nie automatycznym potwierdzeniem incydentu. ..."
}
```

Gdzie w raporcie są wymagane informacje:

| Wymaganie | Pole w JSON |
|---|---|
| ścieżka pliku | `source_file` (+ `source_sha256`) |
| próg alarmowy | `detection.threshold`, `detection.alert_rule` |
| linie przeanalizowane | `stats.lines_analyzed` |
| linie z nieudanym logowaniem | `stats.lines_matched_failed_password` |
| linie pominięte | `stats.lines_skipped` |
| linie z błędem parsowania | `stats.lines_parse_errors` + `parse_errors` |
| lista IP i liczba prób | `results[].source_ip`, `results[].failed_logins` |
| które IP przekroczyły próg | `results[].alert`, `summary` |
| zastrzeżenie interpretacyjne | `note` |

`counters_consistent` sprawdza dwa równania: `przeanalizowane = dopasowane + pominięte`
(500 = 402 + 98) oraz `dopasowane = sparsowane + błędy` (402 = 399 + 3).
Dzięki temu widać, że żadna linia nie zginęła po drodze.

---

## Część 7 — raport CSV

> Dodaj opcjonalny raport CSV.
>
> Minimalne kolumny: `source_ip,failed_logins,alert`
>
> Zasady:
>
> - `alert` powinno wskazywać, czy IP przekroczyło próg,
> - CSV powinien zawierać jeden wiersz per IP,
> - raport nie powinien zawierać pełnych linii logu,
> - raport powinien być możliwy do otwarcia w arkuszu lub w `pandas`.

### Rozwiązanie

```python
CSV_FIELDS = ["source_ip", "failed_logins", "alert", "ioc_match", "category"]

def write_csv(rows: list[dict], path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:   # newline="" — bez pustych wierszy na Windows
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
```

CSV jest opcjonalny: domyślnie powstaje, a `--no-csv` go wyłącza. `extrasaction="ignore"` pomija pola
spoza listy kolumn, więc do CSV nie trafią fragmenty logu ani listy użytkowników.

`output/ssh-bruteforce-summary.csv`:

```csv
source_ip,failed_logins,alert,ioc_match,category
203.0.113.77,155,True,True,threshold_and_ioc
203.0.113.10,124,True,True,threshold_and_ioc
198.51.100.61,45,True,False,threshold_only
203.0.113.88,32,True,False,threshold_only
192.0.2.120,18,True,False,threshold_only
198.51.100.90,9,True,False,threshold_only
192.0.2.200,4,True,False,threshold_only
192.0.2.31,3,False,False,none
198.51.100.23,3,False,False,none
192.0.2.55,2,False,False,none
198.51.100.112,2,False,False,none
192.0.2.42,1,False,False,none
203.0.113.130,1,False,False,none
```

Plik ma 13 wierszy, po jednym na IP, i trzy minimalne kolumny na początku. `pandas.read_csv`
rozpoznaje `True`/`False` jako typ `bool` (sprawdzone w części 9).

---

## Część 8 — IOC

> Porównaj adresy IP znalezione w logu z listą `data/ioc-ips.txt`.
>
> Wymagania:
>
> 1. Wczytaj listę IOC z pliku.
> 2. Usuń puste linie.
> 3. Porównaj zaobserwowane IP z listą referencyjną.
> 4. Oznacz w raporcie IP znajdujące się na liście IOC.
> 5. Nie opisuj dopasowania jako potwierdzonego incydentu.
>
> Raport powinien rozróżniać:
>
> - IP przekraczające próg,
> - IP znajdujące się na liście IOC,
> - IP spełniające oba warunki.

### Rozwiązanie

```python
def load_ioc(path: Path) -> tuple[set[str], list[str]]:
    validate_input_file(path)                          # 1. ten sam bezpieczny odczyt
    iocs, invalid = set(), []
    for _, raw in iter_lines(path):
        value = raw.split("#", 1)[0].strip()           # komentarze i białe znaki
        if not value:                                  # 2. puste linie
            continue
        try:
            iocs.add(str(ipaddress.ip_address(value))) # normalizacja + walidacja wpisu
        except ValueError:
            invalid.append(value)                      # błędny wpis → ostrzeżenie, nie crash
    return iocs, invalid


def classify(alert: bool, ioc_match: bool) -> str:
    if alert and ioc_match:
        return "threshold_and_ioc"
    if alert:
        return "threshold_only"
    if ioc_match:
        return "ioc_only"
    return "none"

# w build_report() — 3–4. porównanie i oznaczenie
ioc_match = bool(iocs) and ip in iocs
"matched_ips":         sorted(observed & iocs)   # część wspólna zbiorów
"not_observed_in_log": sorted(iocs - observed)   # IOC, których nie było w logu
```

Wynik dla `data/ioc-ips.txt` (`203.0.113.10`, `203.0.113.77`, `198.51.100.50`):

| Kategoria | IP |
|---|---|
| tylko próg (`threshold_only`) | `198.51.100.61`, `203.0.113.88`, `192.0.2.120`, `198.51.100.90`, `192.0.2.200` |
| tylko IOC (`ioc_only`) | — (brak w danych przy progu 3) |
| oba warunki (`threshold_and_ioc`) | `203.0.113.77`, `203.0.113.10` |
| IOC niewidoczne w logu | `198.51.100.50` |

Kategoria `ioc_only` działa, co pokazują dwa sprawdzenia:

- `python ssh_bruteforce_parser.py -t 200`: przy progu 200 oba adresy z IOC trafiają do `ioc_only`.
- Test `test_ioc_blank_lines_comments_and_ioc_only_category` używa listy IOC z `192.0.2.42`.
  Ten adres ma 1 próbę, więc ląduje w `ioc_only`. Ta sama lista ma pustą linię, komentarz i błędny
  wpis `nie-ip`; błędny wpis trafia do ostrzeżenia, a parser działa dalej.

Wymaganie 5: pole `note` i komunikat na konsoli mówią wprost, że dopasowanie do IOC to zgodność
z listą referencyjną, a nie dowód ataku. Nazwy kategorii opisują, *co się zgadza*,
a nie wydają werdyktu (żadnych etykiet typu „incident” albo „malicious”).

---

## Część 9 — `pandas` jako rozszerzenie

> Ta część jest opcjonalna, ale zalecana.
>
> Wymagania:
>
> 1. Zainstaluj `pandas` i `numpy` w `venv`.
> 2. Zapisz zależności w `requirements.txt`.
> 3. Wczytaj wygenerowany CSV do `DataFrame`.
> 4. Sprawdź pierwsze rekordy.
> 5. Sprawdź kolumny.
> 6. Posortuj dane po liczbie nieudanych logowań.
> 7. Wyświetl TOP 10 IP.
> 8. Przefiltruj tylko rekordy z alertem.
> 9. Zapisz przefiltrowany wynik do osobnego CSV.
>
> Ważne: `pandas` analizuje wynik parsera. Nie powinien zastępować zrozumienia formatu logu ani poprawnego parsowania danych wejściowych.

### Rozwiązanie

```bash
python -m venv .venv && source .venv/bin/activate      # 1.
python -m pip install pandas numpy
python -m pip freeze > requirements-lock.txt           # 2. (requirements.txt: pandas>=2.0, numpy>=1.24)
python ssh_bruteforce_parser.py
python pandas_analysis.py
```

```python
import pandas as pd

df = pd.read_csv("output/ssh-bruteforce-summary.csv", dtype={"source_ip": "string"})  # 3.
print(df.head())                                                                        # 4.
print(list(df.columns)); df.info()                                                      # 5.
df_sorted = df.sort_values(["failed_logins", "source_ip"], ascending=[False, True])     # 6.
print(df_sorted.head(10))                                                               # 7.
alerts = df_sorted[df_sorted["alert"]]                                                  # 8.
alerts.to_csv("output/ssh-bruteforce-alerts.csv", index=False)                          # 9.
```

`source_ip` wczytuję jako tekst (`dtype="string"`), żeby pandas nie próbował interpretować adresu jako
liczby. Kolumna `alert` ma typ `bool`, więc filtr `df[df["alert"]]` działa bez porównania `== True`.

Wynik (`python pandas_analysis.py`, skrót):

```text
== df.columns ==
['source_ip', 'failed_logins', 'alert', 'ioc_match', 'category']

== df.info() ==
RangeIndex: 13 entries, 0 to 12
 0   source_ip      13 non-null     string
 1   failed_logins  13 non-null     int64
 2   alert          13 non-null     bool
 3   ioc_match      13 non-null     bool
 4   category       13 non-null     str

== Rekordy z alertem: 7 ==
    source_ip  failed_logins  alert  ioc_match          category
 203.0.113.77            155   True       True threshold_and_ioc
 203.0.113.10            124   True       True threshold_and_ioc
198.51.100.61             45   True      False    threshold_only
 203.0.113.88             32   True      False    threshold_only
  192.0.2.120             18   True      False    threshold_only
198.51.100.90              9   True      False    threshold_only
  192.0.2.200              4   True      False    threshold_only

== Tabela krzyżowa alert x ioc_match ==
ioc_match  False  True
alert
False          6      0
True           5      2

Wszystkie nieudane logowania: 399; TOP 2 IP: 279 (69.9%)
Zapisano: output/ssh-bruteforce-alerts.csv
```

Mediana to 4 próby, średnia 30,7. Rozkład jest mocno skośny: dwa adresy odpowiadają za prawie
70% wszystkich nieudanych logowań. pandas pracuje tu wyłącznie na CSV z parsera, a surowy log
dalej czyta parser w bibliotece standardowej.

---

## Część 10 — bonus: Apache/Nginx

> Na podstawie `data/apache-sample.log` przygotuj prostą analizę web scanning.
>
> Wymagania:
>
> 1. Czytaj log webowy linia po linii.
> 2. Wyciągnij adres IP.
> 3. Wyciągnij metodę HTTP.
> 4. Wyciągnij ścieżkę.
> 5. Wyciągnij kod statusu.
> 6. Zlicz odpowiedzi `404` per IP.
> 7. Oznacz IP z dużą liczbą odpowiedzi `404`.
> 8. Przygotuj TOP ścieżek zwracających `404`.
> 9. Zwróć uwagę na user-agent.
>
> Cel bonusu: zobaczyć, że parser musi być dopasowany do formatu logu. Parser SSH i parser webowy nie są tym samym narzędziem.

### Rozwiązanie

Plik `web_scan_parser.py`. Z parsera SSH importuje tylko bezpieczny odczyt pliku
(`validate_input_file`, `iter_lines`); regex i pola są zupełnie inne.

```python
# Combined Log Format:
# IP ident user [timestamp] "METHOD PATH PROTOCOL" STATUS SIZE "REFERER" "USER-AGENT"
COMBINED_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<timestamp>[^\]]+)\] '
    r'"(?P<method>[A-Z]+) (?P<path>\S+) (?P<protocol>[^"]+)" '
    r'(?P<status>\d{3}) (?P<size>\d+|-) '
    r'"(?P<referer>[^"]*)" "(?P<user_agent>[^"]*)"'
)

for line_number, line in iter_lines(path):             # 1. linia po linii
    match = COMBINED_RE.match(line)
    if not match:
        stats["lines_parse_errors"] += 1
        continue
    ip = str(ipaddress.ip_address(match.group("ip")))   # 2.
    method = match.group("method")                      # 3.
    path_value = match.group("path")                    # 4. dokładnie, z query stringiem
    status = match.group("status")                      # 5.
    user_agents_per_ip[ip][match.group("user_agent")] += 1   # 9.
    if status == "404":
        not_found_per_ip[ip] += 1                       # 6.
        not_found_paths[path_value] += 1                # 8.

alert = count > threshold                               # 7. domyślnie próg 10
```

Wynik (`python web_scan_parser.py`): 1000 linii, 0 błędów parsowania, 317 odpowiedzi `404`.

| IP | 404 | Wszystkie żądania | Udział 404 | Różne ścieżki 404 | Alert (>10) | User-agent |
|---|---:|---:|---:|---:|:---:|---|
| `203.0.113.10` | 180 | 190 | 95% | 15 | **TAK** | `curl/8.0` |
| `203.0.113.77` | 85 | 126 | 68% | 15 | **TAK** | `python-requests/2.32.3` |
| `198.51.100.61` | 40 | 40 | 100% | 13 | **TAK** | `curl/8.0` |
| `192.0.2.55` | 6 | 43 | 14% | 6 | nie | Chrome + gołe `Mozilla/5.0` |
| `198.51.100.23` | 3 | 40 | 8% | 3 | nie | Chrome |
| `192.0.2.80` | 2 | 40 | 5% | 2 | nie | Safari |
| `198.51.100.112` | 1 | 47 | 2% | 1 | nie | Chrome |

TOP 10 ścieżek z `404`:

| Ścieżka | 404 |
|---|---:|
| `/admin` | 52 |
| `/.env` | 39 |
| `/phpmyadmin` | 37 |
| `/wp-admin` | 28 |
| `/api/debug` | 21 |
| `/wp-login.php` | 18 |
| `/cgi-bin/` | 16 |
| `/actuator/health` | 14 |
| `/config.php` | 13 |
| `/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php` | 13 |

Rozkład statusów: 200: 465, 201: 10, 204: 10, 301: 15, 302: 15, 304: 77, 400: 10, 401: 40,
403: 11, 404: 317, 429: 10, 500: 15, 503: 5. Wszystko zgodne z `expected-results.md`.

**User-agent (wymaganie 9):**

- Trzy adresy z alertem używają narzędzi, nie przeglądarek: `curl/8.0` i `python-requests`.
  Parser oznacza to polem `tool_like_user_agent`.
- To tylko heurystyka. User-agent ustawia klient, więc skaner może podawać się za Chrome,
  a legalny monitoring może używać `curl`.
- Gołe `Mozilla/5.0` (bez systemu i silnika) przy `192.0.2.55` też jest nietypowe,
  ale 6 odpowiedzi 404 to za mało, żeby wyciągać wnioski.

**Wnioski:**

- `203.0.113.10` jest najbardziej podejrzany: 95% odpowiedzi to 404, ścieżki są typowe dla skanerów
  (`/.env`, `/phpmyadmin`, `eval-stdin.php`), a serwer zaczął go ograniczać (`429` × 10).
- `203.0.113.77` poza skanowaniem wysłał 41 × `POST /login` (401 × 30, 403 × 11).
  To wygląda na próby logowania także w aplikacji webowej.
- Te same trzy adresy (`203.0.113.10`, `203.0.113.77`, `198.51.100.61`) są w alercie SSH.
  Korelacja dwóch źródeł wzmacnia hipotezę zautomatyzowanego rekonesansu, ale wciąż jest sygnałem
  do weryfikacji, a nie dowodem.
- Żaden z tych adresów nie dostał `200` na wrażliwej ścieżce.
- Parser SSH uruchomiony na logu Apache daje 0 dopasowań (test
  `test_ssh_parser_does_not_understand_web_log`). Format logu wymusza osobny parser.

---

## Część 11 — testy końcowe

> | Test | Oczekiwane zachowanie |
> |---|---|
> | poprawny `auth-sample.log` | raport JSON powstaje w `output/` |
> | pusty plik | raport pokazuje 0 dopasowań |
> | plik bez `Failed password` | raport pokazuje 0 dopasowań |
> | nieistniejący plik | czytelny błąd |
> | ścieżka do katalogu | czytelny błąd |
> | próg `3` | co najmniej jedno IP z danych testowych powinno wejść w alert |
> | lista IOC | raport oznacza dopasowania do `ioc-ips.txt` |

### Rozwiązanie

Ręczne uruchomienia CLI:

| Test | Polecenie | Wynik |
|---|---|---|
| poprawny `auth-sample.log` | `python ssh_bruteforce_parser.py` | `output/ssh-bruteforce-summary.json` i `.csv` powstają, kod 0 ✅ |
| pusty plik | `python ssh_bruteforce_parser.py -i tests/fixtures/empty.log` | 0 przeanalizowanych, 0 dopasowań, raport powstaje ✅ |
| plik bez `Failed password` | `python ssh_bruteforce_parser.py -i tests/fixtures/no-failed.log` | 3 przeanalizowane, 0 dopasowań, 3 pominięte ✅ |
| nieistniejący plik | `python ssh_bruteforce_parser.py -i data/nie-ma-takiego.log` | `Błąd: Plik wejściowy nie istnieje: ...`, kod 2 ✅ |
| ścieżka do katalogu | `python ssh_bruteforce_parser.py -i data` | `Błąd: Ścieżka wejściowa nie jest plikiem ...`, kod 2 ✅ |
| próg `3` | `python ssh_bruteforce_parser.py -t 3` | 7 IP w alercie ✅ |
| lista IOC | `python ssh_bruteforce_parser.py --ioc data/ioc-ips.txt` | `203.0.113.10`, `203.0.113.77` oznaczone `ioc_match: true` ✅ |

Automatycznie: `python -m unittest discover -s tests -v` daje **31 testów, wszystkie OK**:

- testy pozytywne i negatywne regexa,
- liczniki i wyniki per IP porównane z `expected-results.md`,
- pusty plik, plik bez dopasowań, brak pliku, katalog, brak pliku IOC,
- IOC z pustymi liniami i komentarzami, kategoria `ioc_only`,
- CSV bez linii logu,
- niezmieniony SHA-256 pliku źródłowego,
- blokada zapisu raportu na plik źródłowy,
- parser webowy (404 per IP, TOP ścieżek, statusy, user-agent).

Dodatkowo niepoprawny argument (`-t -1`) daje czytelny błąd `argparse`: `próg nie może być ujemny`.

---

## Część 12 — pytania kontrolne

### 1. Czym różni się filtrowanie linii od parsowania pól?

**Odpowiedź:** Filtrowanie to decyzja tak/nie: czy linia nas interesuje. W tym labie to sprawdzenie,
czy zawiera tekst `Failed password`. Nie interesuje nas struktura linii, operacja jest tania i prosta.

Parsowanie rozkłada linię, która przeszła filtr, na pola według wzorca formatu: IP, użytkownik,
port, timestamp. Wymaga znajomości formatu i może się nie udać.

Rozdzielenie tych etapów daje dwa liczniki i pozwala zauważyć linie, które są interesujące,
ale mają nieoczekiwany format. W danych testowych są 3 takie linie (402 dopasowane − 399 sparsowanych).
Bez rozdzielenia takie linie zniknęłyby po cichu albo zepsuły wynik. Filtr zmniejsza też liczbę linii,
na których uruchamiamy droższy regex.

### 2. Dlaczego parser powinien czytać log linia po linii?

**Odpowiedź:**

- **Pamięć:** logi produkcyjne mają gigabajty. `read()` albo `readlines()` ładuje cały plik do RAM,
  a iteracja po pliku trzyma w pamięci jedną linię naraz, niezależnie od rozmiaru logu.
- **Format:** w syslogu jedna linia to jedno zdarzenie, więc linia jest naturalną jednostką analizy.
- **Odporność:** wadliwa linia jest liczona jako pominięta albo błąd i nie przerywa analizy.
  Licznik linii daje numer linii do raportu błędów.
- **Strumieniowość:** to samo podejście działa dla strumienia (`tail -f`, potok z `journalctl`)
  i dla plików, które wciąż rosną.

### 3. Dlaczego regex do IPv4 nie musi oznaczać pełnej walidacji IP?

**Odpowiedź:** Regex sprawdza kształt tekstu, a nie znaczenie. Wzorzec
`\d{1,3}(?:\.\d{1,3}){3}` dopasuje też `999.300.1.1` albo `256.0.0.1`: cztery grupy cyfr
z kropkami, ale nie poprawny adres. Nie sprawdza zakresu oktetów 0–255 i nie rozróżnia
adresów prywatnych, zarezerwowanych czy dokumentacyjnych.

Regex pełniący też rolę walidatora byłby długi i nieczytelny. Lepiej rozdzielić zadania:

- regex wyciąga kandydata z właściwego miejsca linii (między `from` a `port`),
- `ipaddress.IPv4Address()` sprawdza, czy kandydat jest poprawnym adresem.

Mój parser robi to w dwóch krokach i osobno liczy `invalid_ip_value`.

Nawet poprawny technicznie adres nie musi wskazywać rzeczywistego sprawcy: po drodze mogą być
NAT, proxy, VPN albo Tor.

### 4. Co oznacza przekroczenie progu alarmowego?

**Odpowiedź:** Tylko tyle, że liczba nieudanych logowań z danego IP w analizowanym pliku była
większa niż przyjęta granica. Tutaj: więcej niż 3. To sygnał do triage, który mówi
„ten adres zachowuje się inaczej niż tło i warto mu się przyjrzeć”, a nie werdykt.

Próg nie mówi:

- czy atak się udał,
- jaka była intencja (pomyłka użytkownika, skrypt ze starym hasłem, wielu użytkowników za jednym NAT),
- jak szybko padały próby (bez okna czasowego 4 próby w sekundę i 4 próby w tydzień ważą tyle samo).

Granica jest umowna: `192.0.2.200` z 4 próbami ma alert, a `198.51.100.23` z 3 próbami nie,
choć różni je jedna próba. A to właśnie `198.51.100.23` ma ciekawszy kontekst. Nieudane próby
dotyczyły kont `root` i nieistniejącego `oracle`, a później z tego samego IP są 4 udane logowania
na inne konto (`analyst`). Może to być zwykły użytkownik za wspólnym NAT, ale też ktoś, kto
najpierw sondował konta, a potem zalogował się poprawnymi danymi. Kontekst jest więc ważniejszy
niż sam próg.

W realnym środowisku próg dobiera się do normalnego tła, zwykle w oknie czasowym (np. > 20 prób
w 5 minut) i osobno dla różnych typów kont.

### 5. Dlaczego dopasowanie do IOC nie jest automatycznym potwierdzeniem incydentu?

**Odpowiedź:** IOC to wskaźnik, że dany adres był kiedyś powiązany z podejrzaną aktywnością,
a nie dowód, że teraz doszło do naruszenia. Powody:

- **Nieaktualność:** adresy IP zmieniają właściciela (chmura, dynamiczne IP, CGNAT, VPN), a listy IOC
  się starzeją.
- **Jakość źródła:** listy zawierają fałszywe trafienia i często nie podają, dlaczego wpis się
  na nich znalazł.
- **Brak skutku:** incydent wymaga stwierdzenia naruszenia, np. udanego logowania i działań na systemie.
  W tych danych `203.0.113.10` i `203.0.113.77` są na liście IOC i powyżej progu, ale nie mają ani
  jednego udanego logowania w tym logu. To próba ataku, a nie potwierdzone włamanie
  (o ile inne źródła nie powiedzą inaczej).
- **Lista to nie obserwacja:** `198.51.100.50` jest na liście, a w logu nie występuje.

Dopasowanie do IOC podnosi priorytet, ale decyzję podejmuje analityk po zebraniu kontekstu.

### 6. Jakie informacje powinien zawierać raport, aby był wiarygodny?

**Odpowiedź:**

- **Co analizowano:** ścieżka pliku i jego skrót SHA-256 (żeby potwierdzić, że chodzi o ten sam,
  niezmieniony plik), zakres czasu danych.
- **Kiedy i jak:** czas wygenerowania, użyty filtr i regex, próg wraz z warunkiem (`>` czy `>=`),
  użyta lista IOC i liczba jej wpisów.
- **Kompletność:** liczba linii przeanalizowanych, dopasowanych, pominiętych i z błędem parsowania,
  plus sprawdzenie, czy się sumują. Do tego przykłady błędów z numerami linii.
- **Wyniki:** lista IP z liczbą prób, z rozróżnieniem kategorii (próg / IOC / oba) i z kontekstem:
  pierwsze i ostatnie wystąpienie, konta, udane logowania z tego IP.
- **Ograniczenia i interpretacja:** zastrzeżenie, że to sygnał, a nie potwierdzony incydent, oraz znane
  ograniczenia (np. tylko IPv4, brak roku w syslogu).
- **Powtarzalność i minimalizm:** deterministyczne sortowanie, żeby dwa uruchomienia dały ten sam
  wynik, i brak nadmiarowych danych wrażliwych (w CSV nie ma pełnych linii logu).

### 7. Kiedy warto użyć `pandas`, a kiedy wystarczy biblioteka standardowa?

**Odpowiedź:** Biblioteka standardowa (`pathlib`, `re`, `collections.Counter`, `json`, `csv`) wystarczy,
gdy:

- trzeba czytać log strumieniowo i robić proste agregacje (zliczanie, próg, TOP N),
- narzędzie ma działać wszędzie bez instalacji, np. na serwerze bez internetu, w minimalnym
  kontenerze albo na systemie objętym incydentem,
- ważna jest niska zależność i mały rozmiar.

`pandas` warto użyć, gdy:

- dane są już tabelaryczne (np. CSV z parsera),
- potrzebne są wielokrotne grupowania, tabele krzyżowe i statystyki opisowe,
- trzeba łączyć źródła (np. SSH i web po IP),
- trzeba analizować szeregi czasowe (`resample` co 5 minut),
- dane eksploruje się interaktywnie albo trzeba robić wykresy.

`pandas` nie zastępuje parsera. Wczytanie surowego logu o rozmiarze kilku GB do DataFrame zajmie
dużo pamięci i nadal wymaga znajomości formatu. Dlatego w labie parsowanie jest w bibliotece
standardowej, a pandas analizuje wynik.

### 8. Dlaczego nie należy modyfikować pliku źródłowego?

**Odpowiedź:**

- **Integralność dowodowa:** log może być materiałem dowodowym, a każda zmiana podważa
  wiarygodność i łańcuch dowodowy.
- **Powtarzalność:** ktoś inny musi móc odtworzyć analizę na tych samych danych i dostać ten sam wynik.
- **Bezpieczeństwo danych:** błąd w skrypcie, np. otwarcie pliku w trybie `"w"`, może bezpowrotnie
  zniszczyć jedyną kopię logu.
- **Inni odbiorcy:** z tego samego pliku korzystają inne systemy (SIEM, logrotate, inne zespoły).
- **Zacieranie śladów:** zmiana pliku może przypadkowo usunąć albo przesłonić ślady incydentu.

Mój parser chroni źródło na kilka sposobów:

- otwiera plik tylko do odczytu (`"r"`),
- liczy SHA-256 przed i po analizie i zapisuje skrót w raporcie,
- zapisuje wyniki wyłącznie do `output/`,
- odmawia zapisu raportu na ścieżkę pliku źródłowego.

W praktyce analizuje się kopię, a oryginał zostaje nienaruszony.

---

## Kryteria zaliczenia — weryfikacja

> Minimalny rezultat:
>
> - parser czyta `auth.log` linia po linii,
> - parser wykrywa nieudane logowania SSH,
> - parser wyciąga IP,
> - parser zlicza próby per IP,
> - parser stosuje próg alarmowy,
> - parser zapisuje raport JSON,
> - parser obsługuje brak pliku,
> - raport zawiera liczbę przeanalizowanych i dopasowanych linii.
>
> Pełny rezultat:
>
> - parser używa `pathlib`,
> - parser raportuje pominięte i niepasujące linie,
> - parser zapisuje CSV,
> - parser porównuje IP z listą IOC,
> - parser nie nadinterpretuje wyniku,
> - opcjonalna analiza `pandas` działa na wygenerowanym CSV,
> - bonusowy parser webowy wykrywa wiele odpowiedzi `404` per IP.

| Kryterium | Status | Gdzie |
|---|:---:|---|
| czyta linia po linii | ✅ | `iter_lines()` |
| wykrywa nieudane logowania | ✅ | `is_failed_login()`, 402 linie |
| wyciąga IP | ✅ | `FAILED_LOGIN_RE`, 399 adresów |
| zlicza per IP | ✅ | `IpStats`, 13 IP |
| próg alarmowy | ✅ | `exceeds_threshold()`, 7 alertów |
| raport JSON | ✅ | `output/ssh-bruteforce-summary.json` |
| obsługa braku pliku | ✅ | `InputFileError`, kod 2 |
| liczba linii przeanalizowanych i dopasowanych | ✅ | `stats` w JSON |
| `pathlib` | ✅ | wszystkie ścieżki |
| pominięte i niepasujące linie | ✅ | `lines_skipped`, `lines_parse_errors`, `parse_errors.samples` |
| CSV | ✅ | `output/ssh-bruteforce-summary.csv` |
| IOC | ✅ | `load_ioc()`, `classify()`, 2 dopasowania |
| brak nadinterpretacji | ✅ | `note`, neutralne kategorie |
| pandas na wygenerowanym CSV | ✅ | `pandas_analysis.py` → `output/ssh-bruteforce-alerts.csv` |
| bonus web: wiele 404 per IP | ✅ | `web_scan_parser.py`, 3 IP w alercie, `203.0.113.10` na czele |
