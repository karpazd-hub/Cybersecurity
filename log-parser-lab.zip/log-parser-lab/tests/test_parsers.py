"""
Testy do labu 20 (biblioteka standardowa: unittest).

Uruchomienie z katalogu projektu:
    python -m unittest discover -s tests -v
"""

from __future__ import annotations

import csv
import io
import json
import sys
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))

import ssh_bruteforce_parser as ssh  # noqa: E402
import web_scan_parser as web  # noqa: E402

AUTH_SAMPLE = PROJECT_DIR / "data" / "auth-sample.log"
APACHE_SAMPLE = PROJECT_DIR / "data" / "apache-sample.log"
IOC_SAMPLE = PROJECT_DIR / "data" / "ioc-ips.txt"


def run_cli(module, *args: str) -> tuple[int, str, str]:
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        code = module.main(list(args))
    return code, out.getvalue(), err.getvalue()


class TestFilterAndRegex(unittest.TestCase):
    """Część 3 i 4 — testy pozytywne i negatywne pojedynczych linii."""

    def test_positive_root(self):
        line = ("Jul 24 10:00:01 labhost sshd[1001]: Failed password for root "
                "from 203.0.113.10 port 51234 ssh2")
        self.assertTrue(ssh.is_failed_login(line))
        record, error = ssh.parse_failed_login(line)
        self.assertIsNone(error)
        self.assertEqual(record["source_ip"], "203.0.113.10")
        self.assertEqual(record["user"], "root")
        self.assertFalse(record["invalid_user"])
        self.assertEqual(record["timestamp"], "Jul 24 10:00:01")

    def test_positive_invalid_user(self):
        line = ("Jul 24 10:00:09 labhost sshd[1003]: Failed password for invalid user admin "
                "from 203.0.113.10 port 51236 ssh2")
        record, error = ssh.parse_failed_login(line)
        self.assertIsNone(error)
        self.assertEqual(record["source_ip"], "203.0.113.10")
        self.assertEqual(record["user"], "admin")
        self.assertTrue(record["invalid_user"])

    def test_negative_accepted_login(self):
        line = ("Jul 24 10:01:00 labhost sshd[1005]: Accepted password for student "
                "from 192.0.2.15 port 42000 ssh2")
        self.assertFalse(ssh.is_failed_login(line))

    def test_negative_line_without_ip(self):
        for line in (
            "Jul 24 10:08:00 labhost sshd[1018]: Failed password for root from not-an-ip port 62001 ssh2",
            "Jul 24 11:40:00 labhost sshd[2411]: Failed password for root from unknown port 62002 ssh2",
            "Jul 24 11:45:00 labhost sshd[2412]: Failed password unexpected format",
        ):
            self.assertTrue(ssh.is_failed_login(line))          # przechodzi filtr...
            record, error = ssh.parse_failed_login(line)        # ...ale nie wzorzec
            self.assertIsNone(record)
            self.assertEqual(error, "no_ip_pattern")

    def test_negative_other_ssh_message(self):
        for line in (
            "Jul 24 10:07:00 labhost sshd[1017]: Invalid user git from 203.0.113.88 port 62000",
            "Jul 24 10:03:00 labhost sshd[1009]: Connection closed by authenticating user root "
            "198.51.100.23 port 50225 [preauth]",
        ):
            self.assertFalse(ssh.is_failed_login(line))

    def test_regex_gives_candidate_not_valid_ip(self):
        line = ("Jul 24 10:00:01 labhost sshd[1]: Failed password for root "
                "from 999.300.1.1 port 1 ssh2")
        self.assertIsNotNone(ssh.FAILED_LOGIN_RE.search(line))  # regex pasuje...
        record, error = ssh.parse_failed_login(line)
        self.assertIsNone(record)                                # ...walidacja odrzuca
        self.assertEqual(error, "invalid_ip_value")

    def test_iso_timestamp_and_empty_username(self):
        line = ("2026-07-24T10:00:01.123456+02:00 labhost sshd-session[77]: Failed password "
                "for invalid user  from 192.0.2.9 port 4000 ssh2")
        record, error = ssh.parse_failed_login(line)
        self.assertIsNone(error)
        self.assertEqual(record["source_ip"], "192.0.2.9")
        self.assertEqual(record["user"], "")
        self.assertTrue(record["timestamp"].startswith("2026-07-24T10:00:01"))

    def test_threshold_is_strictly_greater(self):
        self.assertFalse(ssh.exceeds_threshold(3, 3))
        self.assertTrue(ssh.exceeds_threshold(4, 3))


class TestSampleAgainstExpectedResults(unittest.TestCase):
    """Porównanie z materials/expected-results.md."""

    EXPECTED = {
        "203.0.113.77": 155, "203.0.113.10": 124, "198.51.100.61": 45,
        "203.0.113.88": 32, "192.0.2.120": 18, "198.51.100.90": 9,
        "192.0.2.200": 4, "198.51.100.23": 3, "192.0.2.31": 3,
        "192.0.2.55": 2, "198.51.100.112": 2, "192.0.2.42": 1, "203.0.113.130": 1,
    }

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.out = Path(cls.tmp.name)
        cls.hash_before = ssh.sha256_of_file(AUTH_SAMPLE)
        cls.code, cls.stdout, cls.stderr = run_cli(
            ssh, "--input", str(AUTH_SAMPLE), "--output-dir", str(cls.out),
            "--threshold", "3", "--ioc", str(IOC_SAMPLE))
        cls.report = json.loads((cls.out / ssh.JSON_NAME).read_text(encoding="utf-8"))

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_exit_code_and_json_created(self):
        self.assertEqual(self.code, 0)
        self.assertTrue((self.out / ssh.JSON_NAME).is_file())

    def test_line_counters(self):
        s = self.report["stats"]
        self.assertEqual(s["lines_analyzed"], 500)
        self.assertEqual(s["lines_matched_failed_password"], 402)
        self.assertEqual(s["lines_parsed_ok"], 399)
        self.assertEqual(s["lines_parse_errors"], 3)
        self.assertEqual(s["lines_skipped"], 98)
        self.assertEqual(s["unique_source_ips"], 13)
        self.assertTrue(s["counters_consistent"])

    def test_counts_per_ip(self):
        got = {r["source_ip"]: r["failed_logins"] for r in self.report["results"]}
        self.assertEqual(got, self.EXPECTED)

    def test_sorted_descending(self):
        counts = [r["failed_logins"] for r in self.report["results"]]
        self.assertEqual(counts, sorted(counts, reverse=True))

    def test_threshold_3_gives_7_alerts(self):
        alerts = {r["source_ip"] for r in self.report["results"] if r["alert"]}
        self.assertEqual(alerts, {ip for ip, c in self.EXPECTED.items() if c > 3})
        self.assertEqual(len(alerts), 7)

    def test_ioc_matches(self):
        self.assertEqual(self.report["ioc"]["matched_ips"], ["203.0.113.10", "203.0.113.77"])
        self.assertEqual(self.report["ioc"]["not_observed_in_log"], ["198.51.100.50"])
        self.assertEqual(sorted(self.report["summary"]["threshold_and_ioc"]),
                         ["203.0.113.10", "203.0.113.77"])

    def test_report_has_disclaimer(self):
        self.assertIn("nie automatycznym potwierdzeniem incydentu", self.report["note"])

    def test_csv_one_row_per_ip_without_log_lines(self):
        with (self.out / ssh.CSV_NAME).open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(len(rows), 13)
        self.assertEqual(list(rows[0])[:3], ["source_ip", "failed_logins", "alert"])
        self.assertFalse(any("sshd" in v for row in rows for v in row.values()))

    def test_source_file_not_modified(self):
        self.assertEqual(ssh.sha256_of_file(AUTH_SAMPLE), self.hash_before)
        self.assertEqual(self.report["source_sha256"], self.hash_before)


class TestEdgeCases(unittest.TestCase):
    """Część 11 — pusty plik, brak 'Failed password', brak pliku, katalog, IOC-only."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.out = self.dir / "output"

    def tearDown(self):
        self.tmp.cleanup()

    def _report(self):
        return json.loads((self.out / ssh.JSON_NAME).read_text(encoding="utf-8"))

    def test_empty_file(self):
        empty = self.dir / "empty.log"
        empty.write_text("", encoding="utf-8")
        code, _, _ = run_cli(ssh, "-i", str(empty), "-o", str(self.out), "--no-ioc")
        self.assertEqual(code, 0)
        stats = self._report()["stats"]
        self.assertEqual(stats["lines_analyzed"], 0)
        self.assertEqual(stats["lines_matched_failed_password"], 0)

    def test_file_without_failed_password(self):
        log = self.dir / "clean.log"
        log.write_text(
            "Jul 24 10:01:00 labhost sshd[1]: Accepted password for student from 192.0.2.15 port 1 ssh2\n"
            "Jul 24 10:09:00 labhost CRON[2]: pam_unix(cron:session): session opened for user root\n",
            encoding="utf-8")
        code, _, _ = run_cli(ssh, "-i", str(log), "-o", str(self.out), "--no-ioc")
        self.assertEqual(code, 0)
        stats = self._report()["stats"]
        self.assertEqual(stats["lines_analyzed"], 2)
        self.assertEqual(stats["lines_matched_failed_password"], 0)
        self.assertEqual(stats["lines_skipped"], 2)
        self.assertEqual(self._report()["results"], [])

    def test_missing_file(self):
        code, out, err = run_cli(ssh, "-i", str(self.dir / "brak.log"), "-o", str(self.out))
        self.assertEqual(code, 2)
        self.assertIn("nie istnieje", err)
        self.assertFalse(self.out.exists())

    def test_directory_instead_of_file(self):
        code, _, err = run_cli(ssh, "-i", str(self.dir), "-o", str(self.out))
        self.assertEqual(code, 2)
        self.assertIn("nie jest plikiem", err)

    def test_missing_ioc_file(self):
        code, _, err = run_cli(ssh, "-i", str(AUTH_SAMPLE), "-o", str(self.out),
                               "--ioc", str(self.dir / "brak-ioc.txt"))
        self.assertEqual(code, 2)
        self.assertIn("nie istnieje", err)

    def test_ioc_blank_lines_comments_and_ioc_only_category(self):
        ioc = self.dir / "ioc.txt"
        ioc.write_text("\n# komentarz\n 192.0.2.42 \n\nnie-ip\n203.0.113.77\n", encoding="utf-8")
        iocs, invalid = ssh.load_ioc(ioc)
        self.assertEqual(iocs, {"192.0.2.42", "203.0.113.77"})
        self.assertEqual(invalid, ["nie-ip"])
        code, _, _ = run_cli(ssh, "-i", str(AUTH_SAMPLE), "-o", str(self.out), "--ioc", str(ioc))
        self.assertEqual(code, 0)
        summary = self._report()["summary"]
        self.assertEqual(summary["ioc_only"], ["192.0.2.42"])           # IOC, ale pod progiem
        self.assertEqual(summary["threshold_and_ioc"], ["203.0.113.77"])  # oba warunki
        self.assertIn("198.51.100.61", summary["threshold_only"])        # tylko próg

    def test_report_cannot_overwrite_source(self):
        log = self.dir / ssh.JSON_NAME
        log.write_text("Jul 24 10:00:01 h sshd[1]: Failed password for root from 192.0.2.1 port 1 ssh2\n",
                       encoding="utf-8")
        before = log.read_text(encoding="utf-8")
        code, _, err = run_cli(ssh, "-i", str(log), "-o", str(self.dir), "--no-ioc")
        self.assertEqual(code, 2)
        self.assertIn("plik źródłowy", err)
        self.assertEqual(log.read_text(encoding="utf-8"), before)

    def test_filter_only_mode(self):
        code, out, _ = run_cli(ssh, "-i", str(AUTH_SAMPLE), "--filter-only")
        self.assertEqual(code, 0)
        counts = json.loads(out)
        self.assertEqual(counts, {"lines_analyzed": 500, "lines_matched_filter": 402,
                                  "lines_not_matched": 98})


class TestWebParser(unittest.TestCase):
    """Część 10 — bonus: Apache Combined Log."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.out = Path(cls.tmp.name)
        cls.code, _, _ = run_cli(web, "-i", str(APACHE_SAMPLE), "-o", str(cls.out))
        cls.report = json.loads((cls.out / web.JSON_NAME).read_text(encoding="utf-8"))

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_counts(self):
        self.assertEqual(self.code, 0)
        self.assertEqual(self.report["stats"]["lines_analyzed"], 1000)
        self.assertEqual(self.report["stats"]["lines_parse_errors"], 0)
        self.assertEqual(self.report["stats"]["total_404"], 317)

    def test_404_per_ip(self):
        got = {r["source_ip"]: r["not_found_404"] for r in self.report["results"]}
        self.assertEqual(got, {"203.0.113.10": 180, "203.0.113.77": 85, "198.51.100.61": 40,
                               "192.0.2.55": 6, "198.51.100.23": 3, "192.0.2.80": 2,
                               "198.51.100.112": 1})
        self.assertEqual(self.report["results"][0]["source_ip"], "203.0.113.10")

    def test_top_paths(self):
        top = {p["path"]: p["count"] for p in self.report["top_404_paths"]}
        self.assertEqual(top["/admin"], 52)
        self.assertEqual(top["/.env"], 39)
        self.assertEqual(top["/config.php"], 13)
        self.assertEqual(len(top), 10)

    def test_status_distribution(self):
        self.assertEqual(self.report["status_distribution"], {
            "200": 465, "201": 10, "204": 10, "301": 15, "302": 15, "304": 77, "400": 10,
            "401": 40, "403": 11, "404": 317, "429": 10, "500": 15, "503": 5})

    def test_user_agent_flag(self):
        flagged = {r["source_ip"] for r in self.report["results"] if r["tool_like_user_agent"]}
        self.assertEqual(flagged, {"203.0.113.10", "203.0.113.77", "198.51.100.61"})

    def test_ssh_parser_does_not_understand_web_log(self):
        # Parser SSH na logu webowym: 0 dopasowań — to inne narzędzie do innego formatu.
        result = ssh.analyze_log(APACHE_SAMPLE)
        self.assertEqual(result.lines_matched_filter, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
