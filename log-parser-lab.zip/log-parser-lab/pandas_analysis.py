#!/usr/bin/env python3
"""
pandas_analysis.py — Lab 20, część 9: analiza wyniku parsera w pandas.

pandas pracuje na WYNIKU parsera (output/ssh-bruteforce-summary.csv),
a nie na surowym logu — parsowanie formatu auth.log zostaje w parserze.

Uruchomienie (w aktywnym venv):
    python ssh_bruteforce_parser.py
    python pandas_analysis.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
CSV_IN = BASE_DIR / "output" / "ssh-bruteforce-summary.csv"
CSV_ALERTS = BASE_DIR / "output" / "ssh-bruteforce-alerts.csv"


def to_bool(series: pd.Series) -> pd.Series:
    """Ujednolica kolumnę logiczną niezależnie od zapisu (True/true/1)."""
    if series.dtype == bool:
        return series
    return series.astype(str).str.strip().str.lower().isin(["true", "1", "yes", "tak"])


def main() -> int:
    if not CSV_IN.is_file():
        print(f"Błąd: brak pliku {CSV_IN.name} — najpierw uruchom ssh_bruteforce_parser.py",
              file=sys.stderr)
        return 2

    # 3. Wczytanie wygenerowanego CSV do DataFrame
    df = pd.read_csv(CSV_IN, dtype={"source_ip": "string"})
    for column in ("alert", "ioc_match"):
        if column in df.columns:
            df[column] = to_bool(df[column])

    # 4. Pierwsze rekordy
    print("== df.head() ==")
    print(df.head().to_string(index=False))

    # 5. Kolumny i typy
    print("\n== df.columns ==")
    print(list(df.columns))
    print("\n== df.info() ==")
    df.info()

    # 6. Sortowanie po liczbie nieudanych logowań
    df_sorted = df.sort_values(["failed_logins", "source_ip"], ascending=[False, True])

    # 7. TOP 10 IP
    print("\n== TOP 10 IP wg failed_logins ==")
    print(df_sorted.head(10).to_string(index=False))

    # 8. Tylko rekordy z alertem
    alerts = df_sorted[df_sorted["alert"]]
    print(f"\n== Rekordy z alertem: {len(alerts)} ==")
    print(alerts.to_string(index=False))

    # Dodatkowo: przecięcie alert x IOC oraz udział TOP 2 IP we wszystkich próbach
    if "ioc_match" in df.columns:
        print("\n== Tabela krzyżowa alert x ioc_match ==")
        print(pd.crosstab(df["alert"], df["ioc_match"]))
    total = int(df["failed_logins"].sum())
    top2 = int(df_sorted.head(2)["failed_logins"].sum())
    print(f"\nWszystkie nieudane logowania: {total}; TOP 2 IP: {top2} ({top2 / total:.1%})")
    print("\n== Statystyki failed_logins ==")
    print(df["failed_logins"].describe().round(2).to_string())

    # 9. Zapis przefiltrowanego wyniku do osobnego CSV
    alerts.to_csv(CSV_ALERTS, index=False)
    print(f"\nZapisano: output/{CSV_ALERTS.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
