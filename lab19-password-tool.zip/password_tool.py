"""password-tool — narzędzie CLI do walidacji haseł TESTOWYCH.

Ten plik zawiera wyłącznie obsługę CLI (argparse), konfiguracji JSON
i plików wejściowych. Logika walidacji znajduje się w password_validator.py.

Kody wyjścia:
    0 - wszystkie sprawdzone hasła spełniają politykę
    1 - co najmniej jedno hasło nie spełnia polityki
    2 - błąd argumentów, konfiguracji lub pliku wejściowego
"""
import argparse
import json
import os
import sys

from password_validator import DEFAULT_SPECIAL_CHARS, PasswordValidator

EXIT_OK = 0
EXIT_INVALID = 1
EXIT_ERROR = 2

LOCAL_CONFIG_NAME = "config.json"

# Polityka wbudowana narzędzia CLI (efektywna min. długość = 16).
BUILTIN_POLICY = {
    "min_length": 16,
    "require_lower": True,
    "require_upper": True,
    "require_digit": True,
    "require_special": True,
    "special_chars": DEFAULT_SPECIAL_CHARS,
}

# Dozwolone klucze config.json i ich oczekiwane typy.
ALLOWED_KEYS = {
    "min_length": int,
    "require_lower": bool,
    "require_upper": bool,
    "require_digit": bool,
    "require_special": bool,
    "special_chars": str,
}

TYPE_NAMES = {
    int: "liczbą całkowitą",
    bool: "wartością logiczną (true/false)",
    str: "tekstem",
}


class ConfigError(Exception):
    """Błąd wczytywania lub walidacji konfiguracji polityki."""


# ---------------------------------------------------------------- argumenty CLI

def positive_int(value):
    """Typ argparse: liczba całkowita większa od 0."""
    try:
        number = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"błąd konfiguracji: '{value}' nie jest liczbą całkowitą"
        )
    if number < 1:
        raise argparse.ArgumentTypeError(
            f"błąd konfiguracji: minimalna długość musi być większa od 0 (podano: {number})"
        )
    return number


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        prog="password_tool.py",
        description=(
            "Walidator haseł TESTOWYCH według polityki bezpieczeństwa. "
            "Raport nigdy nie wypisuje sprawdzanych haseł."
        ),
        epilog=(
            "Priorytet ustawień: jawny argument CLI -> config.json -> wartości wbudowane. "
            "UWAGA: nie podawaj prawdziwych haseł jako argumentów CLI "
            "(trafiają m.in. do historii powłoki i listy procesów)."
        ),
    )
    parser.add_argument(
        "--min-length",
        type=positive_int,
        default=None,  # None = użytkownik nie podał; 16 stosujemy przy łączeniu konfiguracji
        metavar="N",
        help="minimalna długość hasła (liczba > 0); domyślnie z config.json albo 16",
    )
    parser.add_argument(
        "--config",
        metavar="SCIEZKA",
        help="plik JSON z polityką walidacji (domyślnie lokalny config.json, jeśli istnieje)",
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--password",
        metavar="HASLO",
        help="pojedyncze hasło TESTOWE do sprawdzenia",
    )
    source.add_argument(
        "--file",
        metavar="PLIK",
        help="plik z hasłami testowymi (jedno hasło w linii)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="szczegółowy raport (źródło i efektywna polityka) bez ujawniania haseł",
    )
    return parser.parse_args(argv)


# ---------------------------------------------------------------- konfiguracja

def resolve_config_path(config_arg):
    """Zwraca (ścieżka, czy_jawnie_podana) lub (None, False) gdy brak pliku."""
    if config_arg is not None:
        return config_arg, True
    if os.path.isfile(LOCAL_CONFIG_NAME):
        return LOCAL_CONFIG_NAME, False
    return None, False


def load_config(config_path):
    """Wczytuje plik JSON z polityką i zwraca zwalidowany słownik."""
    try:
        with open(config_path, "r", encoding="utf-8") as config_file:
            config = json.load(config_file)
    except FileNotFoundError:
        raise ConfigError(f"plik konfiguracyjny '{config_path}' nie istnieje.")
    except IsADirectoryError:
        raise ConfigError(f"'{config_path}' jest katalogiem, a nie plikiem JSON.")
    except PermissionError:
        raise ConfigError(f"brak uprawnień do odczytu pliku '{config_path}'.")
    except UnicodeDecodeError:
        raise ConfigError(f"plik '{config_path}' nie jest zapisany w kodowaniu UTF-8.")
    except json.JSONDecodeError as error:
        # Podajemy tylko pozycję błędu, bez treści pliku.
        raise ConfigError(
            f"plik '{config_path}' nie jest poprawnym JSON "
            f"(linia {error.lineno}, kolumna {error.colno}: {error.msg})."
        )

    validate_config(config, config_path)
    return config


def validate_config(config, config_path="config.json"):
    """Sprawdza strukturę, klucze i typy polityki. Rzuca ConfigError."""
    if not isinstance(config, dict):
        raise ConfigError(
            f"plik '{config_path}': główną wartością JSON musi być obiekt {{...}}, "
            f"a jest {type(config).__name__}."
        )

    for key in config:
        if key in ("password", "file"):
            raise ConfigError(
                f"plik '{config_path}': klucz '{key}' jest niedozwolony — "
                "konfiguracja opisuje wyłącznie politykę, nie dane wejściowe."
            )
        if key not in ALLOWED_KEYS:
            raise ConfigError(
                f"plik '{config_path}': nieznany klucz '{key}'. "
                f"Dozwolone: {', '.join(ALLOWED_KEYS)}."
            )

    for key, expected_type in ALLOWED_KEYS.items():
        if key not in config:
            continue
        value = config[key]
        # bool jest podklasą int, więc dla int odrzucamy go osobno
        wrong_type = not isinstance(value, expected_type) or (
            expected_type is int and isinstance(value, bool)
        )
        if wrong_type:
            raise ConfigError(
                f"plik '{config_path}': parametr '{key}' musi być "
                f"{TYPE_NAMES[expected_type]}."
            )

    if "min_length" in config and config["min_length"] < 1:
        raise ConfigError(
            f"plik '{config_path}': parametr 'min_length' musi być większy od 0."
        )

    require_special = config.get("require_special", BUILTIN_POLICY["require_special"])
    special_chars = config.get("special_chars", BUILTIN_POLICY["special_chars"])
    if require_special and special_chars == "":
        raise ConfigError(
            f"plik '{config_path}': niespójna polityka — 'require_special' jest true, "
            "ale 'special_chars' jest pusty."
        )


def build_policy(args, config):
    """Łączy ustawienia: CLI -> config.json -> wartości wbudowane.

    Zwraca (polityka, źródła), gdzie źródła mówią skąd pochodzi każda wartość.
    """
    policy = dict(BUILTIN_POLICY)
    sources = {key: "wbudowane" for key in policy}

    for key, value in (config or {}).items():
        policy[key] = value
        sources[key] = "config"

    if args.min_length is not None:
        policy["min_length"] = args.min_length
        sources["min_length"] = "CLI (--min-length)"

    return policy, sources


# ---------------------------------------------------------------- raport

def print_result(is_valid, problems, label):
    """Wypisuje wynik. Nie dostaje hasła, więc nie może go przypadkiem wypisać."""
    if is_valid:
        print(f"{label}: POPRAWNE (problemy: 0)")
    else:
        print(f"{label}: NIEPOPRAWNE (problemy: {len(problems)})")
        for problem in problems:
            print(f"    - {problem}")


def print_policy(validator, sources, config_path):
    print("[verbose] Źródło konfiguracji:", config_path or "brak (polityka wbudowana)")
    print("[verbose] Efektywna polityka:")
    for key, value in validator.policy().items():
        print(f"[verbose]   {key} = {value!r}  <- {sources[key]}")
    print()


def check_single(validator, password):
    is_valid, problems = validator.validate(password)
    print_result(is_valid, problems, "Hasło testowe")
    return EXIT_OK if is_valid else EXIT_INVALID


def check_file(validator, file_path, verbose=False):
    if not os.path.exists(file_path):
        print(f"Błąd: plik z hasłami '{file_path}' nie istnieje.", file=sys.stderr)
        return EXIT_ERROR
    if not os.path.isfile(file_path):
        print(f"Błąd: '{file_path}' nie jest zwykłym plikiem.", file=sys.stderr)
        return EXIT_ERROR

    valid_count = 0
    total = 0
    try:
        with open(file_path, "r", encoding="utf-8") as passwords_file:
            for line_number, line in enumerate(passwords_file, start=1):
                # Usuwamy tylko znak końca linii — spacje na brzegach to część testu.
                password = line.rstrip("\r\n")
                is_valid, problems = validator.validate(password)
                print_result(is_valid, problems, f"Linia {line_number}")
                total += 1
                valid_count += int(is_valid)
    except PermissionError:
        print(f"Błąd: brak uprawnień do odczytu pliku '{file_path}'.", file=sys.stderr)
        return EXIT_ERROR
    except UnicodeDecodeError:
        print(f"Błąd: plik '{file_path}' nie jest zapisany w UTF-8.", file=sys.stderr)
        return EXIT_ERROR

    print()
    print(f"Podsumowanie: sprawdzono {total}, poprawne {valid_count}, "
          f"niepoprawne {total - valid_count}.")
    if verbose:
        print(f"[verbose] Plik wejściowy: {file_path}")
    return EXIT_OK if valid_count == total else EXIT_INVALID


# ---------------------------------------------------------------- main

def main(argv=None):
    args = parse_args(argv)

    config_path, explicit = resolve_config_path(args.config)
    config = None
    if config_path is not None:
        try:
            config = load_config(config_path)
        except ConfigError as error:
            print(f"Błąd konfiguracji: {error}", file=sys.stderr)
            if not explicit:
                print("Popraw lokalny config.json albo wskaż inny plik przez --config.",
                      file=sys.stderr)
            return EXIT_ERROR

    policy, sources = build_policy(args, config)
    try:
        validator = PasswordValidator(**policy)
    except ValueError as error:
        print(f"Błąd konfiguracji: {error}", file=sys.stderr)
        return EXIT_ERROR

    if args.verbose:
        print_policy(validator, sources, config_path)

    if args.password is not None:
        return check_single(validator, args.password)
    return check_file(validator, args.file, verbose=args.verbose)


if __name__ == "__main__":
    sys.exit(main())
