#!/usr/bin/env bash
# Testy ręczne z części 10 labu. Uruchom z katalogu projektu przy aktywnym venv:
#   source venv/bin/activate
#   bash tests/run_manual_tests.sh | tee tests/wyniki-testow.txt

cd "$(dirname "$0")/.." || exit 2
PY=python

run() {
    local title="$1"; shift
    echo "=================================================================="
    echo "TEST: $title"
    echo "\$ $*"
    echo "------------------------------------------------------------------"
    "$@" 2>&1
    echo "[kod wyjścia: $?]"
    echo
}

run "--help" $PY password_tool.py --help
run "import modułu nie uruchamia programu" $PY -c "import password_validator; print('import OK, nic się nie uruchomiło')"
run "klasa: konfiguracja domyślna i repr" $PY -c "from password_validator import PasswordValidator as V; v=V(); print(repr(v)); print(v.validate('admin'))"
run "klasa: inna minimalna długość" $PY -c "from password_validator import PasswordValidator as V; print(V(min_length=8).validate('Haslo12!'))"
run "klasa: błędna minimalna długość" $PY -c "from password_validator import PasswordValidator as V
try:
    V(min_length=0)
except ValueError as e:
    print('ValueError:', e)"
run "poprawna minimalna długość (--min-length 10)" $PY password_tool.py --verbose --min-length 10 --password 'Haslo12345!'
run "minimalna długość 0" $PY password_tool.py --min-length 0 --password 'Test'
run "minimalna długość ujemna" $PY password_tool.py --min-length -5 --password 'Test'
run "minimalna długość nie-liczbowa" $PY password_tool.py --min-length abc --password 'Test'
run "pojedyncze hasło: za krótkie" $PY password_tool.py --password 'Ab1!'
run "pojedyncze hasło: bez cyfry" $PY password_tool.py --password 'PasswordTestowe!'
run "pojedyncze hasło: bez znaku specjalnego" $PY password_tool.py --password 'Password12345678'
run "pojedyncze hasło: poprawne" $PY password_tool.py --password 'VeryStrongPassword2026!'
run "plik z hasłami (lokalny config.json wykryty automatycznie)" $PY password_tool.py --verbose --file passwords-sample.txt
run "nieistniejący plik z hasłami" $PY password_tool.py --file brak-pliku.txt
run "jednoczesne --password i --file" $PY password_tool.py --password 'Test' --file passwords-sample.txt
run "brak --password i --file" $PY password_tool.py

# Brak config.json: uruchamiamy w katalogu tymczasowym bez config.json
TMPDIR_NOCFG=$(mktemp -d)
cp passwords-sample.txt "$TMPDIR_NOCFG/"
run "brak config.json -> polityka wbudowana (16)" bash -c "cd '$TMPDIR_NOCFG' && $PY '$PWD/password_tool.py' --verbose --password 'VeryStrongPw1!'"
rm -rf "$TMPDIR_NOCFG"

run "poprawny config.json (min_length=14)" $PY password_tool.py --verbose --config config.json --password 'VeryStrongPw1!'
run "--config z innego katalogu" $PY password_tool.py --verbose --config policies/strict.json --password 'TestoweHaslo2026!'
run "--min-length nadpisuje config.json" $PY password_tool.py --verbose --config config.json --min-length 20 --file passwords-sample.txt
run "jawnie wskazany brakujący config" $PY password_tool.py --config nie-ma-takiego.json --password 'Test'
run "niepoprawny JSON" $PY password_tool.py --config tests/configs/invalid-json.json --password 'Test'
run "główna wartość JSON to lista" $PY password_tool.py --config tests/configs/root-list.json --password 'Test'
run "nieznany klucz (literówka)" $PY password_tool.py --config tests/configs/unknown-key.json --password 'Test'
run "niewłaściwy typ pola" $PY password_tool.py --config tests/configs/wrong-type.json --password 'Test'
run "min_length = 0 w JSON" $PY password_tool.py --config tests/configs/zero-length.json --password 'Test'
run "pusty special_chars przy require_special" $PY password_tool.py --config tests/configs/empty-special.json --password 'Test'
run "dane wejściowe (file) w konfiguracji" $PY password_tool.py --config tests/configs/input-in-config.json --password 'Test'
