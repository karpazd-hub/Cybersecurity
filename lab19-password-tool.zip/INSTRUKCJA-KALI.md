# Lab 19 — wykonanie w Kali Linux (VirtualBox)

## 1. Przenieś paczkę do maszyny wirtualnej

Wybierz jeden ze sposobów:

- **Folder współdzielony VirtualBox:** Urządzenia → Foldery współdzielone → dodaj folder z `lab19-password-tool.zip`, zaznacz „Automatyczne montowanie”. W Kali plik będzie w `/media/sf_<nazwa>/` (jeśli brak dostępu: `sudo usermod -aG vboxsf $USER` i wyloguj się).

## 2. Część 1 — przygotowanie projektu (wykonaj w terminalu Kali)

```bash
cd ~
unzip ~/Downloads/lab19-password-tool.zip      # dostosuj ścieżkę do miejsca pobrania
cd password-tool                                 # 1-2. katalog projektu

python3 -m venv venv                             # 3. utworzenie venv (katalog venv NIE jest w paczce)
source venv/bin/activate                         # 4. aktywacja — w prompcie pojawi się (venv)
python --version                                 # 5. wersja Pythona
which python                                     #    powinno wskazać .../password-tool/venv/bin/python
python -m pip --version                          # 6. pip z venv (ścieżka .../venv/lib/...)
python -m pip install -r requirements.txt        #    nic nie instaluje — brak zależności
ls -la                                           # 7-9. password_tool.py, password_validator.py,
                                                 #      passwords-sample.txt, config.json
```


## 3. Części 2-10 — sprawdzenie działania

```bash
python password_tool.py --help
python password_tool.py --password 'VeryStrongPassword2026!'
python password_tool.py --file passwords-sample.txt --verbose
python password_tool.py --config config.json --min-length 20 --file passwords-sample.txt --verbose

# wszystkie 28 testów ręcznych z części 10 naraz, z zapisem wyników:
bash tests/run_manual_tests.sh | tee tests/wyniki-testow.txt
```

Plik `tests/wyniki-testow.txt` w paczce zawiera wyniki z mojego uruchomienia — po uruchomieniu w Kali nadpiszesz go swoimi.

## 4. Na koniec

```bash
deactivate
```

Zrób zrzuty ekranu: aktywnego `(venv)` z `python --version` i `pip --version`, `--help`, trybu pliku oraz kilku testów błędnej konfiguracji.
