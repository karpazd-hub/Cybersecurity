"""Moduł z logiką walidacji haseł.

Moduł udostępnia wyłącznie klasę PasswordValidator. Import modułu nie
pobiera danych od użytkownika, nie czyta argumentów CLI ani plików
i nie uruchamia żadnej walidacji automatycznie.
"""

DEFAULT_MIN_LENGTH = 12
DEFAULT_SPECIAL_CHARS = "!@#$%^&*"


class PasswordValidator:
    """Walidator hasła według konfigurowalnej polityki."""

    def __init__(
        self,
        min_length=DEFAULT_MIN_LENGTH,
        require_lower=True,
        require_upper=True,
        require_digit=True,
        require_special=True,
        special_chars=DEFAULT_SPECIAL_CHARS,
    ):
        # bool jest podklasą int w Pythonie, dlatego odrzucamy go jawnie
        if isinstance(min_length, bool) or not isinstance(min_length, int):
            raise ValueError("min_length musi być liczbą całkowitą.")
        if min_length < 1:
            raise ValueError(
                f"min_length musi być większe od 0 (podano: {min_length})."
            )

        flags = {
            "require_lower": require_lower,
            "require_upper": require_upper,
            "require_digit": require_digit,
            "require_special": require_special,
        }
        for name, value in flags.items():
            if not isinstance(value, bool):
                raise ValueError(f"{name} musi być wartością logiczną (True/False).")

        if not isinstance(special_chars, str):
            raise ValueError("special_chars musi być tekstem.")
        if require_special and special_chars == "":
            raise ValueError(
                "special_chars nie może być pusty, gdy require_special jest włączone."
            )

        self.min_length = min_length
        self.require_lower = require_lower
        self.require_upper = require_upper
        self.require_digit = require_digit
        self.require_special = require_special
        self.special_chars = special_chars

    def validate(self, password):
        """Sprawdza hasło. Zwraca krotkę (czy_poprawne, lista_problemów)."""
        problems = []

        if password == "":
            problems.append("Hasło nie może być puste.")
            return False, problems

        if len(password) < self.min_length:
            problems.append(
                f"Hasło jest za krótkie (wymagane co najmniej {self.min_length} znaków)."
            )

        if password != password.strip(" "):
            problems.append("Hasło nie może zaczynać się ani kończyć spacją.")

        if self.require_lower and not any(c.islower() for c in password):
            problems.append("Brak małej litery.")
        if self.require_upper and not any(c.isupper() for c in password):
            problems.append("Brak wielkiej litery.")
        if self.require_digit and not any(c.isdigit() for c in password):
            problems.append("Brak cyfry.")
        if self.require_special and not any(c in self.special_chars for c in password):
            problems.append(
                f"Brak znaku specjalnego (dozwolone: {' '.join(self.special_chars)})."
            )

        return len(problems) == 0, problems

    def policy(self):
        """Zwraca efektywną politykę jako słownik (bez żadnych haseł)."""
        return {
            "min_length": self.min_length,
            "require_lower": self.require_lower,
            "require_upper": self.require_upper,
            "require_digit": self.require_digit,
            "require_special": self.require_special,
            "special_chars": self.special_chars,
        }

    def __repr__(self):
        # Bezpieczna reprezentacja: tylko polityka, obiekt nigdy nie przechowuje hasła.
        params = ", ".join(f"{key}={value!r}" for key, value in self.policy().items())
        return f"PasswordValidator({params})"

    def __str__(self):
        return (
            f"Polityka: min. {self.min_length} znaków, "
            f"mała litera={'tak' if self.require_lower else 'nie'}, "
            f"wielka litera={'tak' if self.require_upper else 'nie'}, "
            f"cyfra={'tak' if self.require_digit else 'nie'}, "
            f"znak specjalny={'tak' if self.require_special else 'nie'} "
            f"({self.special_chars})"
        )
